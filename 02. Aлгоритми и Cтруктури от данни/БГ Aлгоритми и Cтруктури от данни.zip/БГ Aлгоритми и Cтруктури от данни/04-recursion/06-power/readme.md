# Степен

## Инструкции

Напишете функция наречена `power`, която приема `основа` (base) и `степен` (exponent) и връща резултата от повдигането на `основата` на `степента`. Използвайте рекурсия за решаване на този проблем.

### Сигнатура на функцията

```js
/**
 * Returns the result of raising the base to the power of the exponent.
 * @param {number} base - The base number.
 * @param {number} exponent - The exponent.
 * @returns {number} - The result of the calculation.
 */
function power(base: number, exponent: number): number;
```

### Примери

```js
power(2, 3); // 8 (2^3 = 2 * 2 * 2 = 8)
power(5, 2); // 25 (5^2 = 5 * 5 = 25)
power(3, 4); // 81 (3^4 = 3 * 3 * 3 * 3 = 81)
```

### Ограничения

- Основата и степента винаги ще бъдат положителни цели числа

### Подсказки

- Запомнете, че всяко число, повдигнато на степен 0, е 1. Това трябва да ви даде базовия случай
- Помислете как можете да разделите проблема на по-малки части, използвайки рекурсия

## Решения

<details>
  <summary>Натиснете за решение</summary>

```js
function power(base, exponent) {
  if (exponent === 0) {
    return 1;
  } else {
    return base * power(base, exponent - 1);
  }
}
```

### Обяснение

- Базовият случай на рекурсията е когато степента е 0. В този случай връщаме 1, защото всяко число, повдигнато на степен 0, е 1.
- За всяка друга стойност на степента разделяме проблема на по-малки части. За да повдигнем основата на степента, можем да започнем като умножим основата по резултата от функцията, извикана със същата основа и степента, намалена с 1. Тази рекурсивна стъпка е същността на алгоритъма, тъй като непрекъснато намалява проблема, докато достигне базовия случай.

Нека използваме `power(2, 5)` и да разгледаме точните стъпки, включително достигането на базовия случай и развиването и циклирането през връщанията:

```js
base = 2
exponent = 5
exponent !== 0 so base case is skipped
return 2 * power(2, 4)
exponent = 4
return 2 * power(2, 3)
exponent = 3
return 2 * power(2, 2)
exponent = 2
return 2 * power(2, 1)
exponent = 1
return 2 * power(2, 0)
exponent = 0
return 1
```

Сега започваме развиването:

```js
return 1 * 2 = 2
return 2 * 2 = 4
return 4 * 2 = 8
return 8 * 2 = 16
return 16 * 2 = 32
```

</details>

### Тестови случаи

```js
test('Calculate Power of Base to Exponent', () => {
  expect(power(2, 3)).toEqual(8);
  expect(power(5, 2)).toEqual(25);
  expect(power(3, 4)).toEqual(81);
});
```
