# Предизвикателство: Диапазон от числа чрез рекурсия

## Инструкции

Напишете функция наречена `numberRange`, която приема `startNum` и `endNum` и връща масив от числа от `startNum` до `endNum`, включително. Уверете се, че използвате рекурсия във вашето решение.

### Сигнатура на функцията

```js
/**
 * Returns an array of numbers from startNum to endNum, inclusive.
 * @param {number} startNum - The starting number.
 * @param {number} endNum - The ending number.
 * @returns {number[]} - An array of numbers.
 */
function numberRange(startNum: number, endNum: number): number[];
```

### Примери

```js
numberRange(1, 5); // should return [1, 2, 3, 4, 5]
numberRange(3, 10); // should return [3, 4, 5, 6, 7, 8, 9, 10]
numberRange(7, 7); // should return [7] (only one number)
```

### Подсказки

- Можете да изградите масива, като първо извикате `numberRange` за по-малък диапазон и след това добавите `endNum` към масива.

## Решения

<details>
  <summary>Натиснете за решение</summary>

```js
function numberRange(startNum, endNum) {
  if (startNum === endNum) {
    return [startNum];
  }

  const numbers = numberRange(startNum, endNum - 1);
  numbers.push(endNum);
  return numbers;
}
```

### Обяснение

- Първо добавяме базовия случай и проверяваме дали `startNum` е равен на `endNum`. Ако е така, връщаме `startNum` в масив.
- За рекурсивния случай задаваме променливата `numbers` да е равна на функцията със startNum и едно по-малко от `endNum`.
- След това добавяме `endNum` към масива `numbers` и го връщаме.

Това е същността, но нека разгледаме стъпка по стъпка за `numberRange(1, 5)`

Стъпка 1: Тъй като `startNum(1)` не е равен на `endNum(5)`, преминаваме към рекурсивния блок.

Стъпка 2: Правим рекурсивно извикване на `numberRange(1, 4)`, което ще извика допълнително `numberRange(1, 3)` и т.н., докато достигнем базовия случай.

Стъпка 3: Базовият случай се достига, когато `startNum(1)` стане равен на endNum (1). В този момент функцията връща масив, съдържащ само числото 1.

Стъпка 4: Развиването започва. Резултатът от `numberRange(1, 2)` вече е масив `[1, 2]`. След това резултатът от `numberRange(1, 3)` е `[1, 2, 3]` и т.н., докато накрая получим резултата от `numberRange(1, 5)` като `[1, 2, 3, 4, 5]`.

Функцията следва същия рекурсивен процес за изграждане на масива от числа, започвайки от базовия случай и добавяйки числа едно по едно, докато развива рекурсивните извиквания.

</details>

### Тестови случаи

```js
test('Calculating the range of numbers', () => {
  expect(numberRange(1, 5)).toEqual([1, 2, 3, 4, 5]);
  expect(numberRange(3, 10)).toEqual([3, 4, 5, 6, 7, 8, 9, 10]);
  expect(numberRange(7, 7)).toEqual([7]);
});
```
