# Имплементация на двойно свързан списък

В този урок ще създадем клас за двойно свързан списък в JavaScript. Ако искате да опитате сами, въз основа на знанията, които имате за свързан списък и това, което обясних за двойно свързания списък, опитайте да го имплементирате сами. Ако заседнете, винаги можете да се върнете и да гледате този урок.

Ще сменя подхода и вместо класове ще използвам конструкторна функция и методи върху прототипа.

## Функция `Node`

Първо ще създадем функция `Node`, която ще се използва за създаване на възли за нашия двойно свързан списък. Функцията `Node` ще приема стойност и ще зададе свойството `value` на подадената стойност. Също така ще зададе свойствата `next` и `prev` на `null`.

```js
function Node(data) {
  this.data = data;
  this.next = null;
  this.prev = null;
}
```

## Функция `DoublyLinkedList`

След това ще създадем функция `DoublyLinkedList`, която ще се използва за създаване на двойно свързани списъци. Функцията `DoublyLinkedList` ще зададе свойствата `head` и `tail` на `null` и свойството `length` на `0`.

```js
function DoublyLinkedList() {
  this.head = null;
  this.tail = null;
  this.length = 0;
}
```

## Метод `append`

Ще добавим метод наречен `append` към прототипа на `DoublyLinkedList`. Този метод ще добавя възел в края на двойно свързания списък.

```js
DoublyLinkedList.prototype.append = function (data) {
  const newNode = new Node(data);

  if (!this.head) {
    this.head = newNode;
    this.tail = newNode;
  } else {
    newNode.prev = this.tail;
    this.tail.next = newNode;
    this.tail = newNode;
  }

  this.length++;
};
```

Създаваме нов възел с подадените данни. Ако свойството `head` е `null`, тогава задаваме свойствата `head` и `tail` на новия възел. В противен случай задаваме свойството `prev` на новия възел на текущия `tail` възел. След това задаваме свойството `next` на текущия `tail` възел на новия възел. Накрая задаваме свойството `tail` на новия възел.

Нека изпробваме каквото имаме досега. Добавете това във вашия файл за изпълнение или в края на текущия файл:

```js
const DoublyLinkedList = require('./doubly-linked-list');

const list = new DoublyLinkedList();

list.append(1);
list.append(2);
list.append(3);

console.log(list);
```

Трябва да видите нещо подобно:

```js
DoublyLinkedList {
  head: <ref *1> Node {
    data: 1,
    next: Node { data: 2, next: [Node], prev: [Circular *1] },
    prev: null
  },
  tail: <ref *2> Node {
    data: 3,
    next: null,
    prev: Node { data: 2, next: [Circular *2], prev: [Node] }
  },
  length: 3
}
```

Това ни показва, че имаме двойно свързан списък с възли `head` и `tail`. Възелът `head` има `next` възел, а възелът `tail` има `prev` възел. `prev` на първия възел и `next` на последния възел са и двата `null`.

## Метод `printAll`

Нека създадем метод за отпечатване на всички данни в списъка. Ще добавим метод наречен `printAll` към прототипа на `DoublyLinkedList`.

```js
DoublyLinkedList.prototype.printAll = function () {
  let current = this.head;

  while (current) {
    console.log(current.data);
    current = current.next;
  }
};
```

Можете да тествате със следното:

```js
const list = new DoublyLinkedList();

list.append(1);
list.append(2);
list.append(3);

list.printAll();
```

Трябва да видите нещо подобно:

```bash
1
2
3
```

## Метод `prepend`

Нека добавим функция за добавяне на възел в началото на списъка. Ще наречем тази функция `prepend`. Тя ще приема стойност и ще добавя възел в началото на списъка.

```js
DoublyLinkedList.prototype.prepend = function (data) {
  const newNode = new Node(data);

  if (!this.head) {
    this.head = newNode;
    this.tail = newNode;
  } else {
    newNode.next = this.head;
    this.head.prev = newNode;
    this.head = newNode;
  }

  this.length++;
};
```

Създаваме нов възел с подадените данни. Ако свойството `head` е `null`, тогава задаваме свойствата `head` и `tail` на новия възел. В противен случай задаваме свойството `next` на новия възел на текущия `head` възел. След това задаваме свойството `prev` на текущия `head` възел на новия възел. Накрая задаваме свойството `head` на новия възел.

Можете да опитате със:

```js
const list = new DoublyLinkedList();

list.append(1);
list.append(2);
list.append(3);
list.prepend('Hello');

list.printAll();
```

Трябва да видите нещо подобно:

```bash
Hello
1
2
3
```

## Метод `insert`

Нека добавим функция за вмъкване на възел на конкретен индекс. Ще наречем тази функция `insert`. Тя ще приема индекс и стойност и ще вмъкне възел на този индекс.

```js
DoublyLinkedList.prototype.insert = function (index, data) {
  if (index < 0 || index > this.length) {
    return null;
  }

  if (index === 0) {
    return this.prepend(data);
  }

  if (index === this.length) {
    return this.append(data);
  }

  const newNode = new Node(data);
  let currentNode = this.head;

  for (let i = 0; i < index - 1; i++) {
    currentNode = currentNode.next;
  }

  newNode.next = currentNode.next;
  newNode.prev = currentNode;
  currentNode.next.prev = newNode;
  currentNode.next = newNode;

  this.length++;
};
```

Първо проверяваме дали индексът е валиден. Ако е, проверяваме дали индексът е `0`. Ако е, извикваме метода `prepend`. След това проверяваме дали индексът е равен на дължината на списъка. Ако е, извикваме метода `append`. В противен случай създаваме нов възел с подадените данни.

След това обхождаме списъка, докато стигнем възела преди индекса. Задаваме свойството `next` на новия възел на свойството `next` на текущия възел. Задаваме свойството `prev` на новия възел на текущия възел. Задаваме свойството `prev` на възела след новия на новия възел. Задаваме свойството `next` на текущия възел на новия възел.

Можете да опитате със:

```js
const list = new DoublyLinkedList();

list.append(1);
list.append(2);
list.append(3);
list.prepend('Hello');
list.insert(2, 'World');

list.printAll();
```

Трябва да видите нещо подобно:

```bash
Hello
1
World
2
3
```

## Метод `get`

Нека добавим функция за получаване на възел на конкретен индекс. Ще наречем тази функция `get`. Тя ще приема индекс и ще връща възела на този индекс.

```js
DoublyLinkedList.prototype.get = function (index) {
  if (index < 0 || index >= this.length) {
    return null;
  }

  let currentNode = this.head;
  for (let i = 0; i < index; i++) {
    currentNode = currentNode.next;
  }

  return currentNode;
};
```

Първо проверяваме дали индексът е валиден. Ако е, обхождаме списъка, докато стигнем възела на индекса, и го връщаме.

Можете да опитате със:

```js
console.log(list.get(0));
```

Трябва да видите нещо подобно:

```js
<ref *2> Node {
  data: 'Hello',
  next: <ref *1> Node {
    data: 1,
    next: Node { data: 'World', next: [Node], prev: [Circular *1] },
    prev: [Circular *2]
  },
  prev: null
}
```

## Метод `remove`

Нека добавим функция за премахване на възел на конкретен индекс. Ще наречем тази функция `remove`. Тя ще приема индекс и ще премахне възела на този индекс.

```js
DoublyLinkedList.prototype.remove = function (data) {
  if (!this.head) return;

  let currentNode = this.head;
  while (currentNode) {
    if (currentNode.data === data) {
      if (currentNode === this.head) {
        this.head = currentNode.next;
        if (this.head) {
          this.head.prev = null;
        }
      } else if (currentNode === this.tail) {
        this.tail = currentNode.prev;
        this.tail.next = null;
      } else {
        currentNode.prev.next = currentNode.next;
        currentNode.next.prev = currentNode.prev;
      }

      this.length--;
      return true;
    }

    currentNode = currentNode.next;
  }

  return false;
};
```

Първо проверяваме дали списъкът е празен, като проверяваме дали `head` е `null`. Ако е, връщаме.

Ако не е празен, продължаваме и задаваме `currentNode` на `head`.

След това обхождаме списъка, докато намерим възела с данните, които искаме да премахнем. Ако го намерим, проверяваме дали е `head` възел. Ако е, задаваме `head` на следващия възел. Проверяваме също дали `head` не е `null`. Ако не е, задаваме `prev` на `head` на `null`, защото сега е първият възел.

Ако възелът не е `head`, проверяваме дали е `tail` възел. Ако е, задаваме `tail` на предишния възел. Също задаваме `next` на `tail` на `null`, защото сега е последният възел.

Ако възелът не е нито `head`, нито `tail`, задаваме `next` на предишния възел на следващия възел. Също задаваме `prev` на следващия възел на предишния възел.

След това намаляваме `length` и връщаме `true`.

Ако не намерим възела, връщаме `false`.

Можете да тествате със следния код:

```js
const list = new DoublyLinkedList();

list.append(1);
list.append(2);
list.append(3);
list.prepend('Hello');
list.insert(2, 'World');
list.remove(4);

list.printAll();
```

Сега трябва да видите нещо подобно:

```bash
Hello
1
World
2
3
```

## Тестови случаи

```js
describe('DoublyLinkedList', () => {
  let list;

  beforeEach(() => {
    list = new DoublyLinkedList();
  });

  it('should append elements to the end of the list', () => {
    list.append(1);
    list.append(2);
    expect(list.get(0).data).toBe(1);
    expect(list.get(1).data).toBe(2);
  });

  it('should prepend elements to the beginning of the list', () => {
    list.prepend(1);
    list.prepend(2);
    expect(list.get(0).data).toBe(2);
    expect(list.get(1).data).toBe(1);
  });

  it('should insert elements at a specific index', () => {
    list.append(1);
    list.append(3);
    list.insert(1, 2);
    expect(list.get(0).data).toBe(1);
    expect(list.get(1).data).toBe(2);
    expect(list.get(2).data).toBe(3);
  });

  it('should remove elements from the list', () => {
    list.append(1);
    list.append(2);
    list.append(3);
    list.remove(2);
    expect(list.get(0).data).toBe(1);
    expect(list.get(1).data).toBe(3);
  });

  it('should return null for invalid indices', () => {
    list.append(1);
    expect(list.get(-1)).toBe(null);
    expect(list.get(1)).toBe(null);
  });

  it('should have the correct length after operations', () => {
    expect(list.length).toBe(0);
    list.append(1);
    expect(list.length).toBe(1);
    list.prepend(2);
    expect(list.length).toBe(2);
    list.remove(1);
    expect(list.length).toBe(1);
    list.remove(2);
    expect(list.length).toBe(0);
  });

  it('should handle inserting at the beginning and end correctly', () => {
    list.insert(0, 1);
    list.insert(1, 2);
    expect(list.get(0).data).toBe(1);
    expect(list.get(1).data).toBe(2);
  });

  it('should return true when an item is successfully removed', () => {
    list.append(1);
    list.append(2);
    expect(list.remove(2)).toBe(true);
  });

  it('should return false when removing an item not in the list', () => {
    list.append(1);
    expect(list.remove(2)).toBe(false);
  });
});
```
