# Предизвикателство: Обръщане на низ чрез опашка

## Инструкции

Напишете функция наречена `reverseStringQueue`, която приема низ и връща обратния му вариант.

Функцията трябва да върне обърнатия низ, но искам да използвате класа `Queue`, за да го направите.

### Сигнатура на функцията

```js
/**
 * Returns the reverse of a string.
 * @param {string} str - The string to reverse.
 * @returns {string} - The reverse of the string.
 */
function reverseStringQueue(str: string): string;
```

### Примери

```js
reverseStringQueue('hello'); // olleh
reverseStringQueue('Howdy'); // ydwoH
reverseStringQueue('Greetings from Earth'); // htraE morf sgniteerG
```

### Ограничения

- Низът ще съдържа само малки букви и интервали

### Подсказки

- Добавете (enqueue) всички символи от низа в опашката
- Извадете (dequeue) всички символи от опашката и ги добавете към нов низ

## Решения

<details>
  <summary>Натиснете за решение</summary>

```js
const Queue = require('./queue');

const reverseStringWithQueue = (str) => {
  const queue = new Queue();

  for (let i = str.length - 1; i >= 0; i--) {
    queue.enqueue(str[i]);
  }

  let reversedString = '';
  while (!queue.isEmpty()) {
    reversedString += queue.dequeue();
  }

  return reversedString;
};
```

### Обяснение

- Включете нашия клас за опашка и инициализирайте нова опашка
- Обходете str и добавете (enqueue) всеки символ в опашката.
- Създайте празен низ и извадете (dequeue) всеки символ от опашката и го добавете към низа.
- Върнете низа.

</details>

### Тестови случаи

```js
test('Reversing a string', () => {
  expect(reverseStringQueue('Hello')).toBe('olleH');
  expect(reverseStringQueue('JavaScript')).toBe('tpircSavaJ');
  expect(reverseStringQueue('12345')).toBe('54321');
});
```
