# Предизвикателство: Обръщане на низ чрез свързан списък

## Инструкции

Напишете функция наречена `reverseStringLinkedList`, която приема низ и връща обратния му вариант.

Функцията трябва да върне обърнатия низ, но искам да използвате класа `LinkedList`, за да го направите.

### Сигнатура на функцията

```js
/**
 * Returns the reverse of a string.
 * @param {string} str - The string to reverse.
 * @returns {string} - The reverse of the string.
 */
function reverseStringLinkedList(str: string): string;
```

### Примери

```js
reverseStringQueue('hello'); // olleh
reverseStringQueue('Howdy'); // ydwoH
reverseStringQueue('Greetings from Earth'); // htraE morf sgniteerG
```

### Подсказки

- Обходете низа и добавете всеки символ в свързания списък.
- Обходете свързания списък и изградете обърнатия низ.

## Решения

<details>
  <summary>Натиснете за решение</summary>

```js
function reverseStringLinkedList(str) {
  const list = new LinkedList();

  for (let i = str.length - 1; i >= 0; i--) {
    list.add(str[i]);
  }

  let reversedString = '';
  let current = list.head;

  while (current !== null) {
    reversedString += current.data;
    current = current.next;
  }

  return reversedString;
}
```

### Обяснение

- Инициализирайте нова инстанция на `LinkedList`.
- Обходете низа и добавете всеки символ в свързания списък.
- Инициализирайте променлива `reversedString` и я задайте като празен низ и променлива `current` и я задайте на head на свързания списък.
- Обходете свързания списък и изградете обърнатия низ, като добавите данните на всеки възел към променливата `reversedString` и след това задайте `current` на следващия възел.
- Върнете променливата `reversedString`.

</details>

### Тестови случаи

```js
test('Reversing a string', () => {
  expect(reverseStringLinkedList('Hello')).toBe('olleH');
  expect(reverseStringLinkedList('JavaScript')).toBe('tpircSavaJ');
  expect(reverseStringLinkedList('12345')).toBe('54321');
});
```
