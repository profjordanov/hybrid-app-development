# Предизвикателство: Палиндром чрез опашка и стек

## Инструкции

Ще преразгледаме предизвикателството за палиндром, но този път ще използваме И ДВЕТЕ структури от данни `Queue` и `Stack`, за да го решим.

Създайте функция наречена `isPalindromeQueueStack`, която приема низ и проверява дали е палиндром.

Функцията трябва да връща `true`, ако низът е палиндром, и `false`, ако не е. Отново, използвайте структурите от данни `Queue` и `Stack`, за да решите този проблем. Ако не успеете сами, няма проблем. Това е трудно предизвикателство. Просто се уверете, че разбирате решението.

### Сигнатура на функцията

```js
/**
 * Checks if a string is a palindrome.
 * @param {string} str - The string to check.
 * @returns {boolean} - True if the string is a palindrome, false if it is not.
 */
function isPalindromeQueueStack(str: string): boolean;
```

### Примери

```js
isPalindromeQueueStack('racecar'); // true
isPalindromeQueueStack('hello'); // false
isPalindromeQueueStack('A man, a plan, a canal: Panama'); // true
```

### Подсказки

- Премахнете всички не-буквено-цифрови символи от низа
- Добавете (enqueue) и добавете (push) символите на низа съответно в опашката и стека
- Извадете (dequeue) и извадете (pop) символите съответно от опашката и стека
- Сравнете символите от опашката и стека

## Решения

<details>
  <summary>Натиснете за решение</summary>

```js
function isPalindromeQueueStack(str) {
  const formattedStr = str.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();

  const charQueue = new Queue();
  const charStack = new Stack();

  for (let i = 0; i < formattedStr.length; i++) {
    const char = formattedStr.charAt(i);
    charQueue.enqueue(char);
    charStack.push(char);
  }

  while (!charQueue.isEmpty()) {
    if (charQueue.dequeue() !== charStack.pop()) {
      return false;
    }
  }

  return true;
}
```

### Обяснение

- Премахнете всички не-буквено-цифрови символи от низа и го преобразувайте в малки букви.
- Създайте `Queue` и `Stack` за съхранение на символите на низа.
- Обходете низа и добавете (enqueue) и добавете (push) всеки символ съответно в опашката и стека.
- Проверете дали опашката е празна. Ако не е, извадете (dequeue) и извадете (pop) символите съответно от опашката и стека и ги сравнете. Ако не са равни, върнете `false`.
- Ако преминем през целия низ без да върнем `false`, връщаме `true`.

</details>

### Тестови случаи

```js
test('Checking for palindrome strings', () => {
  expect(isPalindromeQueueStack('racecar')).toBe(true);
  expect(isPalindromeQueueStack('Hello')).toBe(false);
  expect(isPalindromeQueueStack('A man, a plan, a canal, Panama')).toBe(true);
  expect(isPalindromeQueueStack('12321')).toBe(true);
});
```
