# Имплементация на опашка

В миналия урок разгледахме как работи структурата от данни опашка. Тя е `First-in, First-out` или `FIFO`. Първият добавен елемент в опашката ще бъде първият премахнат от нея. Можем да използваме масив като опашка, но можем и да създадем собствен клас за опашка и точно това искам да направим тук.

## Клас Queue и конструктор

Нека започнем, като създадем клас наречен `Queue`. В конструктора ще създадем свойство `queue` и ще го зададем като празен масив. Също така ще създадем свойство `head` и ще го зададем на 0. Ще създадем свойство `tail` и ще го зададем на 0. Накрая ще създадем свойство `maxSize` и ще го зададем на 100 по подразбиране.

```js
class Queue {
  constructor() {
    this.queue = [];
    this.head = 0;
    this.tail = 0;
    this.maxSize = 100;
  }
}
```

## Метод `getLength`

Създайте метода `getLength` и върнете разликата между индексите tail и head.

```js
getLength() {
    return this.tail - this.head;
  }
```

## Метод `isEmpty`

Създайте метода `isEmpty` и върнете булевата стойност на равенството на дължината на опашката с 0.

```js
isEmpty() {
    return this.getLength() === 0;
  }
```

## Метод `isFull`

Създайте метода `isFull` и върнете булевата стойност на равенството на дължината на опашката с maxSize.

```js
isFull() {
    return this.getLength() === this.maxSize;
  }
```

## Метод `enqueue`

Създайте метода `enqueue`. Той ще приема стойност (елемент). Първо, проверете дали опашката е пълна. Ако е, върнете false. Задайте индекса tail на опашката на стойността. Увеличете индекса tail с 1. Върнете true.

```JS
 enqueue(element) {
    if (this.isFull()) {
      return false;
    }
    this.queue[this.tail] = element;
    this.tail++;
    return true;
  }
```

## Метод `dequeue`

Създайте метода `dequeue`. Вземете елемента на индекса head на опашката и го запазете в променлива. Увеличете head с 1. Върнете променливата.

```js
 dequeue() {
    const item = this.queue[this.head];
    this.head++;
    return item;
  }

```

## Метод `peek`

Създайте метода `peek` и върнете елемента на индекса head на опашката.

```js
 peek() {
    return this.queue[this.head];
  }
```

Сега можете да стартирате тестовете и/или да тествате сами със следния код:

```js
const queue = new Queue();
console.log(queue.isEmpty()); // true
console.log(queue.isFull()); // false
console.log(queue.enqueue(1)); // true
console.log(queue.enqueue(2)); // true
console.log(queue.enqueue(3)); // true
console.log(queue.peek()); // 1
console.log(queue.dequeue()); // 1
console.log(queue.peek()); // 2
console.log(queue.getLength()); // 2
```

## Тестови случаи

```js
describe('Queue', () => {
  let queue;

  beforeEach(() => {
    queue = new Queue();
  });

  afterEach(() => {
    queue = null;
  });

  test('enqueue should add an element to the queue', () => {
    queue.enqueue(1);
    expect(queue.getLength()).toBe(1);
    expect(queue.peek()).toBe(1);
  });

  test('dequeue should remove and return the front element from the queue', () => {
    queue.enqueue(1);
    queue.enqueue(2);
    expect(queue.dequeue()).toBe(1);
    expect(queue.getLength()).toBe(1);
    expect(queue.peek()).toBe(2);
  });

  test('peek should return the front element without removing it', () => {
    queue.enqueue(1);
    queue.enqueue(2);
    expect(queue.peek()).toBe(1);
    expect(queue.getLength()).toBe(2);
  });

  test('getLength should return the number of elements in the queue', () => {
    expect(queue.getLength()).toBe(0);
    queue.enqueue(1);
    queue.enqueue(2);
    queue.enqueue(3);
    expect(queue.getLength()).toBe(3);
    queue.dequeue();
    expect(queue.getLength()).toBe(2);
  });

  test('isEmpty should return true if the queue is empty', () => {
    expect(queue.isEmpty()).toBe(true);
    queue.enqueue(1);
    expect(queue.isEmpty()).toBe(false);
    queue.dequeue();
    expect(queue.isEmpty()).toBe(true);
  });

  test('isFull should return true if the queue is full', () => {
    const maxSize = 3;
    const fullQueue = new Queue();
    fullQueue.maxSize = maxSize;
    fullQueue.enqueue(1);
    fullQueue.enqueue(2);
    fullQueue.enqueue(3);
    expect(fullQueue.isFull()).toBe(true);
    fullQueue.dequeue();
    expect(fullQueue.isFull()).toBe(false);
  });
});
```
