# Предизвикателство: Обръщане на низ чрез стек

## Инструкции

Напишете функция наречена `reverseStringStack`, която приема низ и връща обърнатата версия на низа. Уверете се, че използвате класа `Stack`, който създадохме.

Ще ви накарам да направите предизвикателството за обръщане на низ, използвайки различни структури от данни. Може да изглежда прекалено, което е така, но ще ви помогне да разберете как работи всяка структура от данни.

### Сигнатура на функцията

```js
/**
 * Returns the reverse of a string.
 * @param {string} str - The string to reverse.
 * @returns {string} - The reverse of the string.
 */
function reverseStringStack(str: string): string;
```

### Ограничения

- Низът ще съдържа само малки букви и интервали

### Примери

```js
reverseStringStack('hello'); // olleh
reverseStringStack('Howdy'); // ydwoH
reverseStringStack('Greetings from Earth'); // htraE morf sgniteerG
```

### Подсказки

- Добавете (push) всеки символ в стека
- Извадете (pop) символите от стека, за да конструирате обърнатия низ

## Решения

<details>
  <summary>Натиснете за решение</summary>

```js
const Stack = require('./stack');

function reverseString(str) {
  const stack = new Stack();

  // Push each character onto the stack
  for (let i = 0; i < str.length; i++) {
    stack.push(str[i]);
  }

  let reversedString = '';

  // Pop the characters from the stack to construct the reversed string
  while (!stack.isEmpty()) {
    reversedString += stack.pop();
  }

  return reversedString;
}
```

### Обяснение

- Инициализирайте нова инстанция на `Stack`.
- Обходете низа и добавете (push) всеки символ в стека.
- Инициализирайте променлива `reversedString` и я задайте като празен низ.
- Обходете стека и извадете (pop) всеки символ, като го добавите към променливата `reversedString`.
- Върнете променливата `reversedString`.

### Времева и пространствена сложност

Времевата сложност на функцията `reverseString(str)` е `O(n)`, където n е дължината на входния низ str. Това е така, защото функцията обхожда целия низ веднъж, за да добави всеки символ в стека, и след това обхожда стека, за да извади символите и да конструира обърнатия низ. И двете операции отнемат линейно време спрямо дължината на входния низ.

Пространствената сложност на функцията също е `O(n)`, където n е дължината на входния низ str. Това е така, защото функцията използва стек за съхранение на всеки символ от входния низ, и размерът на стека е право пропорционален на дължината на входния низ. Следователно, пространствената сложност нараства линейно с размера на входните данни.

</details>

### Тестови случаи

```js
test('Reversing a string', () => {
  expect(reverseStringStack('Hello')).toBe('olleH');
  expect(reverseStringStack('JavaScript')).toBe('tpircSavaJ');
  expect(reverseStringStack('12345')).toBe('54321');
});
```
