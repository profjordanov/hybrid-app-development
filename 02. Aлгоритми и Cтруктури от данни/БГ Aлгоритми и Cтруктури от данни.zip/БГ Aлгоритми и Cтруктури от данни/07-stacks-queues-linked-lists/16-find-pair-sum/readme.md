## Предизвикателство: Намиране на двойка с дадена сума

Даден ви е масив от цели числа и целева сума. Имплементирайте функция наречена `findPairSum`, която намира и връща двойка различни елементи от масива, чиято сума е равна на целевата сума. Ако такава двойка не съществува, върнете `null`. Трябва да използвате класа/конструктора `DoublyLinkedList` за ефективна имплементация на тази функция.

### Сигнатура на функцията

```javascript
/**
 * Finds a pair of distinct elements from the array whose sum is equal to the target sum.
 * @param {number[]} nums - The array of integers.
 * @param {number} targetSum - The target sum to find.
 * @returns {number[] | null} - An array containing the pair of elements whose sum is the target sum, or null if no such pair exists.
 */
function findPairSum(nums: number[], targetSum: number): number[] | null
```

### Пример

```javascript
const nums = [2, 6, 3, 8, 10, 5];
const targetSum = 12;

const pair = findPairSum(nums, targetSum);
console.log(pair); // Трябва да отпечата: [2, 10]
```

### Подсказки

- Създайте `DoublyLinkedList` за съхранение на срещнатите числа.
- За всяко число в масива изчислете разликата между целевата сума и текущото число.
- Проверете дали изчислената разлика съществува в `DoublyLinkedList`. Ако съществува, сте намерили двойка.

## Решение

<details>
<summary>Натиснете за решение</summary>

```javascript
function findPairSum(nums, targetSum) {
  const seen = new DoublyLinkedList();

  for (const num of nums) {
    const difference = targetSum - num;
    if (seen.contains(difference)) {
      return [difference, num];
    }
    seen.append(num);
  }

  return null;
}
```

- Създайте нов `DoublyLinkedList` наречен `seen` за съхранение на срещнатите числа.
- Обходете входния масив `nums` чрез `for...of` цикъл.
- За всяко число `num` в масива изчислете разликата между целевата сума и текущото число. Запазете разликата в променлива `difference`.
- Проверете дали списъкът `seen` съдържа `difference`. Ако съдържа, върнете масив съдържащ `difference` и `num`.
- В противен случай добавете (append) `num` към списъка `seen`.
- Ако такава двойка не съществува, върнете `null`.

</details>

### Тестови случаи

```javascript
describe('findPair', () => {
  it('should find a pair with the given target sum', () => {
    const nums = [2, 6, 3, 8, 10, 5];
    const targetSum = 12;
    const pair = findPair(nums, targetSum);
    expect(pair).toEqual([2, 10]);
  });

  it('should return null if no such pair exists', () => {
    const nums = [1, 2, 3, 4, 5];
    const targetSum = 10;
    const pair = findPair(nums, targetSum);
    expect(pair).toBeNull();
  });
});
```
