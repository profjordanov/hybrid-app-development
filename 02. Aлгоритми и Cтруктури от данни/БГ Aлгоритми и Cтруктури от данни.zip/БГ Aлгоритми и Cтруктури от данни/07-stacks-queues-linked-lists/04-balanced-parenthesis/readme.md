# Предизвикателство: Балансирани скоби

## Инструкции

Ще опитаме още едно предизвикателство със стек. Напишете функция наречена `isBalanced`, която приема низ и проверява дали скобите са балансирани.

Функцията трябва да връща true, ако скобите са балансирани, и false, ако не са. Използвайте имплементацията на стека, която създадохте в предишното упражнение.

### Сигнатура на функцията

```js
/**
 * Returns true if the parenthesis in a string are balanced.
 * @param {string} str - The string to check.
 * @returns {boolean} - Whether the parenthesis in the string are balanced.
 */
function isBalanced(str: string): boolean;
```

### Примери

```JS
isBalanced('()'); // true
isBalanced('()()'); // true
isBalanced('(()())'); // true
isBalanced('(()'); // false
isBalanced(')('); // false
```

### Ограничения

- Низът ще съдържа само скоби и няма други символи

### Подсказки

- Добавете (push) всяка отваряща скоба в стека
- Извадете (pop) от стека, когато срещнете затваряща скоба
- Ако стекът е празен, когато се срещне затваряща скоба, скобите не са балансирани

## Решения

<details>
  <summary>Натиснете за решение</summary>

```JS
const Stack = require('./stack');

function isBalanced(str) {
const stack = new Stack();

for (let i = 0; i < str.length; i++) {
  if (str[i] === '(') {
    stack.push(str[i]);
  } else if (str[i] === ')') {
    if (stack.isEmpty()) {
      return false;
    }
    stack.pop();
  }
}

return stack.isEmpty();
}
```

### Обяснение

- Включете нашата имплементация на Stack и инициализирайте нов стек.
- Обходете всеки символ от входния низ str и проверете дали текущият символ `str[i]` е отваряща скоба (т.е. '('). Ако е, отварящата скоба се добавя в стека чрез `stack.push(str[i])`.
- Ако текущият символ е затваряща скоба (т.е. ')'), проверете дали стекът е празен чрез `stack.isEmpty()`. Ако стекът е празен в този момент, това означава, че има затваряща скоба без съответна отваряща, затова връщаме false, което показва, че скобите не са балансирани.
- Ако стекът не е празен, това означава, че има съответна отваряща скоба за текущата затваряща. Следователно премахваме горния елемент чрез `stack.pop()`, което представлява успешното сдвояване на отваряща и затваряща скоба.
- След обхождането на всички символи от низа, проверете дали стекът е празен чрез `stack.isEmpty()`. Ако стекът е празен, това означава, че всички отварящи скоби са сдвоени и извадени от стека, което показва балансирани скоби. В този случай връщаме true.
- Ако стекът не е празен след обхождането, това означава, че има несдвоени отварящи скоби, което показва небалансирани скоби. В този случай връщаме `false`.

</details>

### Тестови случаи

```js
describe('balancedParenthesis', () => {
  test('should return true for balanced parentheses', () => {
    expect(balancedParenthesis('()')).toBe(true);
    expect(balancedParenthesis('(())')).toBe(true);
    expect(balancedParenthesis('(()())')).toBe(true);
    expect(balancedParenthesis('((()))')).toBe(true);
    expect(balancedParenthesis('()()()')).toBe(true);
    expect(balancedParenthesis('()((()))()')).toBe(true);
    expect(balancedParenthesis('((()()(())))')).toBe(true);
  });

  test('should return false for unbalanced parentheses', () => {
    expect(balancedParenthesis(')(')).toBe(false);
    expect(balancedParenthesis('((')).toBe(false);
    expect(balancedParenthesis('))')).toBe(false);
    expect(balancedParenthesis('())')).toBe(false);
    expect(balancedParenthesis('(()(()')).toBe(false);
    expect(balancedParenthesis('(()())(')).toBe(false);
    expect(balancedParenthesis('((()()(()))')).toBe(false);
  });
});
```
