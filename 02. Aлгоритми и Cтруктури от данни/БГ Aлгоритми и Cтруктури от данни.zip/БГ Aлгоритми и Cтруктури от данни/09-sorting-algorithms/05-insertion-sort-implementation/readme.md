# Предизвикателство: Алгоритъм Insertion Sort

Сега, след като научихте за алгоритъма Insertion Sort, нека проверим знанията ви и да имплементираме алгоритъма Insertion Sort в JavaScript.

## Инструкции

Имплементирайте функция наречена `insertionSort`, която приема масив от числа като аргумент и връща сортиран масив, използвайки алгоритъма Insertion Sort.

### Сигнатура на функцията

```js
/**
 * Sorts an array using the Insertion Sort algorithm.
 * @param {number[]} array - The array to be sorted.
 * @returns {number[]} - The sorted array.
 */
function insertionSort(arr: number[]): number[]
```

### Примери

```js
console.log(insertionSort([5, 4, 3, 2, 1])); // Output: [1, 2, 3, 4, 5]
console.log(insertionSort([64, 34, 25, 12, 22, 11, 90])); // Output: [11, 12, 22, 25, 34, 64, 90]
```

### Ограничения

- Входният масив може да съдържа произволен брой елементи.
- Елементите във входния масив са уникални и положителни цели числа.

### Забележки

- Алгоритъмът Insertion Sort изгражда крайния сортиран масив елемент по елемент. Той е много по-малко ефективен при големи списъци в сравнение с по-напреднали алгоритми като quicksort, heapsort или merge sort.

### Подсказки

- Разделяй и владей: Основната идея на този алгоритъм е да раздели масива на „сортирана" и „несортирана" част. Първоначално първият елемент се счита за „сортираната" част. След това, един по един, елементите от „несортираната" част се преместват в „сортираната" част, като „сортираната" част остава сортирана.

## Решения

<details>
  <summary>Натиснете за решение</summary>

```js
function insertionSort(arr) {
  for (let i = 1; i < arr.length; i++) {
    const currentElement = arr[i];
    let j = i - 1;

    while (j >= 0 && arr[j] > currentElement) {
      arr[j + 1] = arr[j];
      j--;
    }

    arr[j + 1] = currentElement;
  }

  return arr;
}
```

### Обяснение

- Стартирайте `for` цикъл. Условието на `for` цикъла е `i < arr.length`. Това ще обходи целия масив, започвайки от втория елемент.
- Вътре в `for` цикъла декларирайте променлива наречена `currentElement` и я задайте равна на елемента с индекс `i`. Това е елементът, който искаме да вмъкнем на правилната позиция.
- Декларирайте променлива наречена `j` и я задайте равна на `i - 1`. Това е индексът на последния елемент в „сортираната" част на масива.
- Стартирайте `while` цикъл. Условието на `while` цикъла е `j >= 0` (уверявайки се, че не излизаме извън границите) и `arr[j] > currentElement` (проверявайки дали текущият елемент е по-голям от елемента с индекс `j`).
- Вътре в `while` цикъла преместете елемента с индекс `j` една позиция надясно (като присвоите `arr[j]` на `arr[j + 1]`).
- Намалете `j` с 1, за да преминете към предишния елемент в „сортираната" част.
- След `while` цикъла вмъкнете `currentElement` на правилната позиция в „сортираната" част на масива (като присвоите `currentElement` на `arr[j + 1]`).
- Извън `for` цикъла върнете сортирания масив.

</details>
```

### Тестови случаи

```js
test('Sort an array in ascending order', () => {
  const unsortedArray = [5, 2, 8, 1, 3];
  const sortedArray = [1, 2, 3, 5, 8];
  expect(insertionSort(unsortedArray)).toEqual(sortedArray);
});

test('Sort an array with repeated values', () => {
  const unsortedArray = [4, 1, 3, 4, 2, 2];
  const sortedArray = [1, 2, 2, 3, 4, 4];
  expect(insertionSort(unsortedArray)).toEqual(sortedArray);
});

test('Sort an already sorted array', () => {
  const sortedArray = [1, 2, 3, 4, 5];
  expect(insertionSort(sortedArray)).toEqual(sortedArray);
});

test('Sort an array with one element', () => {
  const singleElementArray = [42];
  expect(insertionSort(singleElementArray)).toEqual(singleElementArray);
});

test('Sort an empty array', () => {
  const emptyArray = [];
  expect(insertionSort(emptyArray)).toEqual(emptyArray);
});
```

Не се колебайте да персонализирате тестовите случаи според вашите нужди!
