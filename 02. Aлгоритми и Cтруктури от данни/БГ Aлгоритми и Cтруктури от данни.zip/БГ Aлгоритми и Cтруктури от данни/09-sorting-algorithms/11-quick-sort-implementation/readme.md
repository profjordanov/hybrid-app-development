# Предизвикателство: Имплементация на Quick Sort

Сега, след като се запознахте с алгоритъма Quick Sort, е време да го имплементирате в JavaScript. Този алгоритъм е високоефективен и използва стратегията „разделяй и владей" за сортиране на масив.

## Инструкции

Имплементирайте функция наречена `quickSort`, която приема масив от числа като аргумент и връща сортиран масив, използвайки алгоритъма Quick Sort.

### Сигнатура на функцията

```js
/**
 * Sorts an array using the Quick Sort algorithm.
 * @param {number[]} array - The array to be sorted.
 * @returns {number[]} - The sorted array.
 */
function quickSort(array: number[]): number[]
```

### Примери

```js
console.log(quickSort([5, 4, 3, 2, 1])); // Output: [1, 2, 3, 4, 5]
console.log(quickSort([64, 34, 25, 12, 22, 11, 90])); // Output: [11, 12, 22, 25, 34, 64, 90]
```

### Ограничения

- Входният масив може да съдържа произволен брой елементи.
- Елементите във входния масив са уникални и положителни цели числа.

### Забележки

- Алгоритъмът Quick Sort включва избиране на опорен елемент, разделяне на масива и рекурсивно сортиране на подмасивите от двете страни на опорния елемент.
- Въпреки че средната времева сложност на Quick Sort е O(n log n), той може да има времева сложност в най-лошия случай O(n^2), ако не е оптимизиран. Оптимизирани методи за избор на опорен елемент, като избор на медианата от три произволни елемента, помагат за смекчаване на този най-лош сценарий.

### Подсказки

- Избор на опорен елемент: Изборът на опорен елемент значително влияе върху ефективността на Quick Sort. Често срещани стратегии за избор на опорен елемент включват избиране на първия, последния или средния елемент, или използване на медианата от три произволни елемента.
- Разделяне: Имплементирайте стъпка за разделяне, която пренарежда елементите така, че елементите, по-малки от опорния, да са вляво, а елементите, по-големи от опорния — вдясно.
- Рекурсия: Рекурсивно приложете алгоритъма Quick Sort върху подмасивите от двете страни на опорния елемент.

## Решения

<details>
  <summary>Click For Solution</summary>

```js
function quickSort(arr) {
  if (arr.length <= 1) {
    return arr;
  }

  const pivot = arr[arr.length - 1];
  const left = [];
  const right = [];

  for (let i = 0; i < arr.length - 1; i++) {
    if (arr[i] < pivot) {
      left.push(arr[i]);
    } else {
      right.push(arr[i]);
    }
  }

  return [...quickSort(left), pivot, ...quickSort(right)];
}
```

### Explanation

- The `quickSort` function is the main sorting function that implements the quick sort algorithm.
- If the length of the array is 1 or less, it is already sorted, so we return the array as is.
- Otherwise, we choose a pivot element (in this case, the last element of the array).
- We create two arrays: `left` to store elements less than the pivot, and `right` to store elements greater than the pivot.
- We iterate through the array and partition the elements into the `left` and `right` arrays based on their relationship to the pivot.
- Finally, we recursively apply `quickSort` to the `left` and `right` arrays, and then concatenate them along with the pivot to get the sorted array.

### Test Cases

```js
test('Sort an array in ascending order', () => {
  const unsortedArray = [5, 2, 8, 1, 3];
  const sortedArray = [1, 2, 3, 5, 8];
  expect(quickSort(unsortedArray)).toEqual(sortedArray);
});

test('Sort an array with repeated values', () => {
  const unsortedArray = [4, 1, 3, 4, 2, 2];
  const sortedArray = [1, 2, 2, 3, 4, 4];
  expect(quickSort(unsortedArray)).toEqual(sortedArray);
});

test('Sort an already sorted array', () => {
  const sortedArray = [1, 2, 3, 4, 5];
  expect(quickSort(sortedArray)).toEqual(sortedArray);
});

test('Sort an array with one element', () => {
  const singleElementArray = [42];
  expect(quickSort(singleElementArray)).toEqual(singleElementArray);
});

test('Sort an empty array', () => {
  const emptyArray = [];
  expect(quickSort(emptyArray)).toEqual(emptyArray);
});
```

Feel free to customize the test cases according to your needs!
```