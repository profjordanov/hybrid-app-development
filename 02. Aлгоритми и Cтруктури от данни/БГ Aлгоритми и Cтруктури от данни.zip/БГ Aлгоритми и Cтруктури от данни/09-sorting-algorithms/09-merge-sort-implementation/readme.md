## Предизвикателство: Имплементация на Merge Sort

Сега, след като се запознахте с алгоритъма Merge Sort, е време да го имплементирате в JavaScript. Този алгоритъм е особено ефективен за големи набори от данни, тъй като използва стратегията „разделяй и владей".

## Инструкции

Имплементирайте функция наречена `mergeSort`, която приема масив от числа като аргумент и връща сортиран масив, използвайки алгоритъма Merge Sort.

### Сигнатура на функцията

```js
/**
 * Sorts an array using the Merge Sort algorithm.
 * @param {number[]} array - The array to be sorted.
 * @returns {number[]} - The sorted array.
 */
function mergeSort(array: number[]): number[]
```

### Примери

```js
console.log(mergeSort([5, 4, 3, 2, 1])); // Output: [1, 2, 3, 4, 5]
console.log(mergeSort([64, 34, 25, 12, 22, 11, 90])); // Output: [11, 12, 22, 25, 34, 64, 90]
```

### Ограничения

- Входният масив може да съдържа произволен брой елементи.
- Елементите във входния масив са уникални и положителни цели числа.

### Забележки

- Алгоритъмът Merge Sort разделя входния масив на по-малки подмасиви, сортира ги поотделно и след това ги слива обратно в правилния ред.

### Подсказки

- Разделяй и владей: Ключовата идея зад този алгоритъм е рекурсивно да разделяте масива на две половини, докато се достигне базовият случай (когато масивът има само един или нула елемента). След това слейте по-малките масиви обратно, като ги сортирате.
- Функция за сливане: Имплементирайте помощна функция наречена `merge`, която приема два сортирани масива и ги слива в един сортиран масив. Тази функция е от решаващо значение за стъпката на сливане на алгоритъма.
- Рекурсивно сортиране: В основната функция `mergeSort` разделете масива на две половини и рекурсивно сортирайте всяка половина. След това използвайте функцията `merge`, за да слеете сортираните половини.

## Решения

<details>
  <summary>Натиснете за решение</summary>

```js
function mergeSort(arr) {
  if (arr.length <= 1) {
    return arr;
  }

  const mid = Math.floor(arr.length / 2);
  const left = mergeSort(arr.slice(0, mid));
  const right = mergeSort(arr.slice(mid));

  return merge(left, right);
}

function merge(left, right) {
  const merged = [];
  let leftIndex = 0;
  let rightIndex = 0;

  while (leftIndex < left.length && rightIndex < right.length) {
    if (left[leftIndex] < right[rightIndex]) {
      merged.push(left[leftIndex]);
      leftIndex++;
    } else {
      merged.push(right[rightIndex]);
      rightIndex++;
    }
  }

  return merged.concat(left.slice(leftIndex)).concat(right.slice(rightIndex));
}
```

### Обяснение

- Функцията `mergeSort` е основната функция за сортиране, която имплементира алгоритъма merge sort.
- Ако дължината на масива е 1 или по-малко, той вече е сортиран, затова връщаме масива както е.
- В противен случай изчисляваме средната точка на масива чрез `Math.floor(arr.length / 2)`.
- Рекурсивно извикваме `mergeSort` за лявата половина и за дясната половина на масива.
- Накрая сливаме сортираните лява и дясна половини чрез функцията `merge`.

- Функцията `merge` приема два сортирани масива като вход и ги слива в един сортиран масив.
- Инициализираме празен масив наречен `merged` за съхранение на слетите елементи.
- Също така инициализираме два индекса: `leftIndex` за левия масив и `rightIndex` за десния масив.
- Обхождаме двата масива, като сравняваме елементите на текущите индекси.
- Ако елементът от левия масив е по-малък, го добавяме в масива `merged` и увеличаваме `leftIndex`.
- Ако елементът от десния масив е по-малък, го добавяме в масива `merged` и увеличаваме `rightIndex`.
- След цикъла конкатенираме всички оставащи елементи от двата масива (ако има такива).
- Връщаме слетия масив.

### Тестови случаи

```js
test('Sort an array in ascending order', () => {
  const unsortedArray = [5, 2, 8, 1, 3];
  const sortedArray = [1, 2, 3, 5, 8];
  expect(mergeSort(unsortedArray)).toEqual(sortedArray);
});

test('Sort an array with repeated values', () => {
  const unsortedArray = [4, 1, 3, 4, 2, 2];
  const sortedArray = [1, 2, 2, 3, 4, 4];
  expect(mergeSort(unsortedArray)).toEqual(sortedArray);
});

test('Sort an already sorted array', () => {
  const sortedArray = [1, 2, 3, 4, 5];
  expect(mergeSort(sortedArray)).toEqual(sortedArray);
});

test('Sort an array with one element', () => {
  const singleElementArray = [42];
  expect(mergeSort(singleElementArray)).toEqual(singleElementArray);
});

test('Sort an empty array', () => {
  const emptyArray = [];
  expect(mergeSort(emptyArray)).toEqual(emptyArray);
});
```

Не се колебайте да персонализирате тестовите случаи според вашите нужди!
