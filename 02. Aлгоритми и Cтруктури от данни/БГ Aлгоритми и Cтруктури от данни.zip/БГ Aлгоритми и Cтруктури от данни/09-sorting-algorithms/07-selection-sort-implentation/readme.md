# Предизвикателство: Имплементация на Selection Sort

Научихте за алгоритъма Selection Sort. Сега е време да приложите знанията си на практика и да имплементирате алгоритъма Selection Sort в JavaScript.

## Инструкции

Имплементирайте функция наречена `selectionSort`, която приема масив от числа като аргумент и връща сортиран масив, използвайки алгоритъма Selection Sort.

### Сигнатура на функцията

```js
/**
 * Sorts an array using the Selection Sort algorithm.
 * @param {number[]} array - The array to be sorted.
 * @returns {number[]} - The sorted array.
 */
function selectionSort(array: number[]): number[]
```

### Примери

```js
console.log(selectionSort([5, 4, 3, 2, 1])); // Output: [1, 2, 3, 4, 5]
console.log(selectionSort([64, 34, 25, 12, 22, 11, 90])); // Output: [11, 12, 22, 25, 34, 64, 90]
```

### Ограничения

- Входният масив може да съдържа произволен брой елементи.
- Елементите във входния масив са уникални и положителни цели числа.

### Забележки

- Алгоритъмът Selection Sort работи чрез многократно намиране на минималния елемент от несортираната част на масива и поставянето му в началото. Този процес продължава, докато целият масив бъде сортиран.

### Подсказки

- Външен цикъл: Основната идея на този алгоритъм е да раздели масива на две части: „сортирана" част и „несортирана" част. Външният цикъл ще обхожда несортираната част и ще избира минималния елемент при всяка итерация.
- Вътрешен цикъл: Вътрешният цикъл ще намира минималния елемент в несортираната част и ще го разменя с първия елемент в несортираната част. Това ефективно премества минималния елемент в сортираната част.
- Текущ минимум: Следете индекса на текущия минимален елемент, намерен във вътрешния цикъл. Ще ви трябва този индекс, за да извършите размяната.

## Решения

<details>
  <summary>Натиснете за решение</summary>

```js
function selectionSort(arr) {
  for (let i = 0; i < arr.length - 1; i++) {
    let minIndex = i;

    for (let j = i + 1; j < arr.length; j++) {
      if (arr[j] < arr[minIndex]) {
        minIndex = j;
      }
    }

    if (minIndex !== i) {
      [arr[i], arr[minIndex]] = [arr[minIndex], arr[i]];
    }
  }

  return arr;
}
```

### Обяснение

- Стартирайте `for` цикъл. Условието на `for` цикъла е `i < arr.length - 1`. Това ще обходи целия масив, с изключение на последния елемент (тъй като последният елемент ще бъде сортиран автоматично).
- Вътре във външния `for` цикъл декларирайте променлива наречена `minIndex` и я задайте на `i`. Тя ще следи индекса на минималния елемент, намерен във вътрешния цикъл.
- Стартирайте вътрешен `for` цикъл. Условието на вътрешния `for` цикъл е `j = i + 1` и `j < arr.length`. Това ще обходи несортираната част на масива.
- Вътре във вътрешния `for` цикъл проверете дали елементът с индекс `j` е по-малък от елемента с индекс `minIndex`. Ако е, обновете `minIndex` на `j`.
- След вътрешния `for` цикъл проверете дали `minIndex` не е равен на `i`. Ако не е равен, разменете елементите с индекси `i` и `minIndex`.
- Извън двата цикъла върнете сортирания масив.

</details>

### Тестови случаи

```js
test('Sort an array in ascending order', () => {
  const unsortedArray = [5, 2, 8, 1, 3];
  const sortedArray = [1, 2, 3, 5, 8];
  expect(selectionSort(unsortedArray)).toEqual(sortedArray);
});

test('Sort an array with repeated values', () => {
  const unsortedArray = [4, 1, 3, 4, 2, 2];
  const sortedArray = [1, 2, 2, 3, 4, 4];
  expect(selectionSort(unsortedArray)).toEqual(sortedArray);
});

test('Sort an already sorted array', () => {
  const sortedArray = [1, 2, 3, 4, 5];
  expect(selectionSort(sortedArray)).toEqual(sortedArray);
});

test('Sort an array with one element', () => {
  const singleElementArray = [42];
  expect(selectionSort(singleElementArray)).toEqual(singleElementArray);
});

test('Sort an empty array', () => {
  const emptyArray = [];
  expect(selectionSort(emptyArray)).toEqual(emptyArray);
});
```

Не се колебайте да персонализирате тестовите случаи според вашите нужди!
