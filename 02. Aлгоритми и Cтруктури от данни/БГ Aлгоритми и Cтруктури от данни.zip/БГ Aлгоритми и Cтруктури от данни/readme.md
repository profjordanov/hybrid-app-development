# Структури от данни и Алгоритми
ИУ-Варна 2026
## Файлова структура

Всяка папка включва:

- `readme.md` - Инструкции за предизвикателството/кода. Тук също са включени подсказки, тестове и падащо меню с кода на решението, както и обяснение на кода на решението.
- `[name].js` - Това е вашият работен файл. Той съдържа името на функцията и функцията е експортирана. Не са подадени параметри към функцията. Това зависи от вас да добавите.
- `[name]-run.js` - Файл за ръчно стартиране на кода. Функцията вече е импортирана и извикана с очакваните параметри.
- `[name]-solution.js` Кодът на решението с подробни коментари. Някои предизвикателства имат множество решения. Ако искате решението без коментари, вижте файла `readme.md`.
- `[name]-test.js` - Jest тестове за кода на решението. Ще трябва да преименувате този файл на `[name].test.js`, за да стартирате тестовете.

## Учебни модули/Уроци

Някои уроци/модули не са предизвикателства, а по-скоро мини-уроци. Не ви давам направо предизвикателство с нова концепция (Дървета, Стекове, Метод на мехурчето и т.н.) без първо да я обясня. Опитвам се да обясня концепцията и след това да ви дам предизвикателство за упражнение или имплементация. Затова някои папки няма да имат предизвикателство, а само readme файл.

## Стартиране на тестове

За да работят Jest тестовете, трябва да преименувате тестовия файл на `[name].test.js`. Например, ако работите по предизвикателството `hello-world`, трябва да преименувате файла `hello-world-test.js` на `hello-world.test.js`. Това е така, защото Jest търси файлове с разширение `.test.js`.

Стартирайте командата `npm run test` от основната директория и тя ще изпълни всички тестове.

## Не е задължително това да бъдат „Предизвикателства"

Някои хора, включително аз самият, не са много добри в това да правят тези неща наизуст. Въпреки че повечето от кода е структуриран като предизвикателство, вие със сигурност можете просто да следвате курса и/или просто да изучавате решенията и да учите от тях.

Можете да използвате тестовете, за да видите дали кодът ви минава, но използвайте `run` файловете, за да стартирате кода ръчно. Това е за да можете да експериментирате, да използвате console.log и т.н.

## Начало

1. Стартирайте `npm install`
2. Стартирайте `npm run test`, за да изпълните тестовете. Отново, ще трябва да преименувате тестовите файлове и да замените `-test` с `.test`, за да стартирате тестовете.

## Индекс на предизвикателствата/уроците

#### 01. Основни предизвикателства 1

Това са предимно предизвикателства, свързани с цикли, условия и манипулация на низове. Не обяснявам основите като „какво е for цикъл". Трябва вече да знаете основите на JavaScript.

1. [Предизвикателство Hello World](./01-basic-challenges-1/01-hello-world/readme.md)
2. [Предизвикателство Get Sum](./01-basic-challenges-1/02-get-sum/readme.md)
3. [Калкулатор](./01-basic-challenges-1/03-calculator/readme.md)
4. [Брой на срещанията](./01-basic-challenges-1/04-count-occurrences/readme.md)
5. [Намиране на максимално число](./01-basic-challenges-1/05-find-max-number/readme.md)
6. [Главни букви](./01-basic-challenges-1/06-title-case/readme.md)
7. [Обръщане на низ](./01-basic-challenges-1/07-reverse-string/readme.md)
8. [Палиндром](./01-basic-challenges-1/08-palindrome/readme.md)
9. [Броене на гласни](./01-basic-challenges-1/09-count-vowels/readme.md)
10. [Премахване на дубликати](./01-basic-challenges-1/10-remove-duplicates/readme.md)

#### 02. Основни предизвикателства 2

Това са повече предизвикателства, свързани с итерации. Те са малко по-трудни от първата група предизвикателства.

1. [FizzBuzz масив](./02-basic-challenges-2/01-fizzbuzz-array/readme.md)
2. [Сечение на масиви](./02-basic-challenges-2/02-array-intersection/readme.md)
3. [Показване на харесвания](./02-basic-challenges-2/03-display-likes/readme.md)
4. [Намиране на липсващо число](./02-basic-challenges-2/04-find-missing-number/readme.md)
5. [Намиране на липсваща буква](./02-basic-challenges-2/05-find-missing-letter/readme.md)
6. [Уникални ли са всички символи](./02-basic-challenges-2/06-are-all-chars-unique/readme.md)
7. [Първи неповтарящ се символ](./02-basic-challenges-2/07-first-non-repeating/readme.md)
8. [Симулация на игра с зарове](./02-basic-challenges-2/08-dice-game/readme.md)
9. [Форматиране на телефонен номер](./02-basic-challenges-2/09-format-phone-number/readme.md)
10. [Валидация на имейл](./02-basic-challenges-2/10-validate-email/readme.md)

#### 03. Методи за масиви от висок ред

Следващата група предизвикателства/уроци ще бъде свързана с методи за масиви от висок ред като `map`, `filter`, `reduce`, `sort` и т.н. Въпреки че повечето от тях могат да бъдат направени с for цикъл, искам да упражнявате използването на тези методи.

1. [Прости примери](./03-high-order-array-methods/01-simple-examples/readme.md)
2. [Сума на четни квадрати](./03-high-order-array-methods/02-sum-of-even-squares/readme.md)
3. [Изчисляване на общи продажби](./03-high-order-array-methods/03-calculate-total-sales/readme.md)
4. [Дума с най-висок резултат](./03-high-order-array-methods/04-highest-scoring-word/readme.md)
5. [Валидни анаграми](./03-high-order-array-methods/05-valid-anagrams/readme.md)
6. [Генератор на хаштагове](./03-high-order-array-methods/06-hashtag-generator/readme.md)
7. [Валиден IPv4 адрес](./03-high-order-array-methods/07-valid-ipv4/readme.md)
8. [Анализ на пробег на автомобил](./03-high-order-array-methods/08-analyze-car-milage/readme.md)
9. [Валидатор на пароли](./03-high-order-array-methods/09-password-validator/readme.md)
10. [Рефакториране на намиране на липсваща буква](./03-high-order-array-methods/10-find-missing-letter-refactor/readme.md)

#### 04. Рекурсия

Следващата група предизвикателства/уроци ще бъде свързана с рекурсия. Първо ще поговорим какво е рекурсия и след това можем да разгледаме някои предизвикателства.

1. [Въведение в рекурсията (Обратно броене)](./04-recursion/01-count-down/readme.md)
2. [Развиване (Сума до)](./04-recursion/02-unwinding/readme.md)
3. [Обръщане на низ с рекурсия](./04-recursion/03-reverse-string-recursion/readme.md)
4. [Редица на Фибоначи](./04-recursion/04-fibonacci-sequence/readme.md)
5. [Факториел](./04-recursion/05-factorial/readme.md)
6. [Степенуване](./04-recursion/06-power/readme.md)
7. [Сума на масив](./04-recursion/07-array-sum/readme.md)
8. [Диапазон от числа](./04-recursion/08-number-range/readme.md)
9. [Изравняване на масив](./04-recursion/09-flatten-array/readme.md)
10. [Пермутации](./04-recursion/10-permutations/readme.md)

#### 05. Сложност

Това е повече учебна секция, отколкото секция с предизвикателства. Ще поговорим за нотацията Big O и как да изчисляваме времевата сложност на алгоритъм. Ще поговорим също за пространствена сложност и как да я изчисляваме. Ще обсъдим различните видове сложност като константна, линейна, квадратична и др.

1. [Какво е времева сложност?](./05-complexity/01-what-is-time-complexity/readme.md)
2. [Нотация Big O](./05-complexity/02-big-o-notation/readme.md)
3. [Константна времева сложност](./05-complexity/03-constant-time-complexity/readme.md)
4. [Линейна времева сложност](./05-complexity/04-linear-time-complexity/readme.md)
5. [Квадратична времева сложност](./05-complexity/05-quadratic-time-complexity/readme.md)
6. [Логаритмична времева сложност](./05-complexity/06-logarithmic-time-complexity/readme.md)
7. [Пространствена сложност](./05-complexity/07-space-complexity/readme.md)
8. [Максимален подмасив - квадратичен](./05-complexity/08-max-subarray-quadratic/readme.md)
9. [Техника на плъзгащ се прозорец](./05-complexity/09-sliding-window-technique/readme.md)
10. [Максимален подмасив - линеен](./05-complexity/10-max-subarray-linear/readme.md)

#### 06. Хеш таблици, Map-ове и Set-ове

В тази секция ще започнем да разглеждаме `структури от данни`. Ще започнем със структура от данни, наречена `хеш таблица`. Тук ще включим `map`-ове и `set`-ове, които са вградени JavaScript структури от данни, подобни на хеш таблици. Ще създадем също и потребителски клас за хеш таблица и ще го използваме в няколко предизвикателства.

1. [Какво са структури от данни?](./06-hash-tables-maps-sets/01-what-are-data-structures/readme.md)
2. [Въведение в хеш таблиците](./06-hash-tables-maps-sets/02-hash-table-intro/readme.md)
3. [Map-ове](./06-hash-tables-maps-sets/03-maps/readme.md)
4. [Брояч на честота на думи](./06-hash-tables-maps-sets/04-word-frequency-counter/readme.md)
5. [Телефонен указател](./06-hash-tables-maps-sets/05-phone-number-directory/readme.md)
6. [Групиране на анаграми](./06-hash-tables-maps-sets/06-anagram-grouping/readme.md)
7. [Set-ове](./06-hash-tables-maps-sets/07-sets/readme.md)
8. [Симетрична разлика](./06-hash-tables-maps-sets/08-symmetric-difference/readme.md)
9. [Сума от две числа](./06-hash-tables-maps-sets/09-two-sum/readme.md)
10. [Най-дълга последователност](./06-hash-tables-maps-sets/10-longest-consecutive/readme.md)
11. [Потребителска хеш таблица](./06-hash-tables-maps-sets/11-custom-hash-table/readme.md)
12. [Брояч на инстанции на думи](./06-hash-tables-maps-sets/12-word-instance-counter/readme.md)
13. [Добавяне на метод getValues()](./06-hash-tables-maps-sets/13-add-get-values-method/readme.md)
14. [Потребителско групиране на анаграми](./06-hash-tables-maps-sets/14-custom-anagram-grouping/readme.md)

#### 07. Стекове, Опашки и Свързани списъци

В тази секция ще разгледаме работата със структури от данни като `стекове`, `опашки` и `свързани списъци`. Ще разгледаме също `бързи` и `бавни` указатели.

1. [Какво е стек?](./07-stacks-queues-linked-lists/01-what-is-a-stack/readme.md)
2. [Имплементация на стек](./07-stacks-queues-linked-lists/02-stack-implementation/readme.md)
3. [Обръщане на низ със стек](./07-stacks-queues-linked-lists/03-reverse-string-stack/readme.md)
4. [Балансирани скоби](./07-stacks-queues-linked-lists/04-balanced-parenthesis/readme.md)
5. [Какво е опашка?](./07-stacks-queues-linked-lists/05-what-is-a-queue/readme.md)
6. [Имплементация на опашка](./07-stacks-queues-linked-lists/06-queue-implementation/readme.md)
7. [Обръщане на низ с опашка](./07-stacks-queues-linked-lists/07-reverse-string-queue/readme.md)
8. [Палиндром с опашка и стек](./07-stacks-queues-linked-lists/08-palindrome-queue-stack/readme.md)
9. [Какво е свързан списък?](./07-stacks-queues-linked-lists/09-what-is-a-linked-list/readme.md)
10. [Имплементация на свързан списък](./07-stacks-queues-linked-lists/10-linked-list-implementation/readme.md)
11. [Обръщане на низ със свързан списък](./07-stacks-queues-linked-lists/11-reverse-string-linked-list/readme.md)
12. [Бързи и бавни указатели](./07-stacks-queues-linked-lists/12-fast-slow-pointers/readme.md)
13. [Намиране на среден елемент](./07-stacks-queues-linked-lists/13-find-middle/readme.md)
14. [Какво е двойно свързан списък?](./07-stacks-queues-linked-lists/14-what-is-a-doubly-linked-list/readme.md)
15. [Имплементация на двойно свързан списък](./07-stacks-queues-linked-lists/15-doubly-linked-list-implementation/readme.md)
16. [Намиране на двойка с дадена сума](./07-stacks-queues-linked-lists/16-find-pair-sum/readme.md)

#### 08. Двоични дървета, Двоични дървета за търсене и Графи

В тази секция ще разгледаме `дървета` и `графи`. Ще започнем с `двоични дървета` и `двоични дървета за търсене`. Ще разгледаме също `графи` и `обхождане на графи`.

1. [Какво е дърво?](./08-binary-trees-graphs/01-what-is-a-tree/readme.md)
2. [Клас възел на дърво](./08-binary-trees-graphs/02-tree-node-class/readme.md)
3. [Обхождане в дълбочина](./08-binary-trees-graphs/03-depth-first-traversal/readme.md)
4. [Рекурсивно обхождане в дълбочина](./08-binary-trees-graphs/04-depth-first-traversal-recursive/readme.md)
5. [Обхождане в ширина](./08-binary-trees-graphs/05-breadth-first-traversal/readme.md)
6. [Максимална дълбочина](./08-binary-trees-graphs/06-maximum-depth/readme.md)
7. [Какво е двоично дърво за търсене?](./08-binary-trees-graphs/07-what-is-a-binary-search-tree/readme.md)
8. [Имплементация на двоично дърво за търсене](./08-binary-trees-graphs/08-binary-search-tree-implementation/readme.md)
9. [Валидация на BST](./08-binary-trees-graphs/09-validate-bst/readme.md)
10. [Какво е граф?](./08-binary-trees-graphs/10-what-is-a-graph/readme.md)
11. [Матрица на съседство и списък на съседство](./08-binary-trees-graphs/11-adjacency-matrix-adjacency-list/readme.md)
12. [Имплементация на граф](./08-binary-trees-graphs/12-graph-implementation/readme.md)
13. [Обхождане на граф](./08-binary-trees-graphs/13-graph-traversal/readme.md)
14. [Обхождане на граф в дълбочина](./08-binary-trees-graphs/14-graph-depth-first-traversal/readme.md)
15. [Обхождане на граф в ширина](./08-binary-trees-graphs/15-graph-breadth-first-traversal/readme.md)

#### 09. Алгоритми за сортиране

В тази секция ще навлезем в алгоритмите за сортиране. Ще започнем с `метод на мехурчето`, който е много популярен на интервюта. Ще разгледаме също `сортиране чрез селекция`, `сортиране чрез вмъкване`, `сортиране чрез сливане` и `бързо сортиране`.

1. [Какво са алгоритмите за сортиране?](./09-sorting-algorithms/01-what-are-sorting-algorithms/readme.md)
2. [Алгоритъм на метода на мехурчето](./09-sorting-algorithms/02-bubble-sort-algorithm/readme.md)
3. [Имплементация на метода на мехурчето](./09-sorting-algorithms/03-bubble-sort-implementation/readme.md)
4. [Алгоритъм за сортиране чрез вмъкване](./09-sorting-algorithms/04-insertion-sort-algorithm/readme.md)
5. [Имплементация на сортиране чрез вмъкване](./09-sorting-algorithms/05-insertion-sort-implementation/readme.md)
6. [Алгоритъм за сортиране чрез селекция](./09-sorting-algorithms/06-selection-sort-algorithm/readme.md)
7. [Имплементация на сортиране чрез селекция](./09-sorting-algorithms/07-selection-sort-implementation/readme.md)
8. [Алгоритъм за сортиране чрез сливане](./09-sorting-algorithms/08-merge-sort-algorithm/readme.md)
9. [Имплементация на сортиране чрез сливане](./09-sorting-algorithms/09-merge-sort-implementation/readme.md)
10. [Алгоритъм за бързо сортиране](./09-sorting-algorithms/10-quick-sort-algorithm/readme.md)
11. [Имплементация на бързо сортиране](./09-sorting-algorithms/11-quick-sort-implementation/readme.md)
