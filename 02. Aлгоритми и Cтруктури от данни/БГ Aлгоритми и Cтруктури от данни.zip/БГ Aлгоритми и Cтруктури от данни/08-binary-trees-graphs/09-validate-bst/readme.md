# Предизвикателство: Валидиране на двоично дърво за търсене

## Инструкции

Напишете функция, наречена `isValidBST`, която приема следните параметри:

- `root` - Коренов/текущ възел на двоично дърво.

Функцията трябва да върне булева стойност, указваща дали двоичното дърво е валидно двоично дърво за търсене (BST).

Трябва да проверите ВСИЧКИ поддървета, не само дясното и лявото на кореновия възел. Бих ви предложил да създадете помощна функция, която да извикате рекурсивно и която приема `min` и `max` стойност. Уверете се, че всичко отляво на възела е по-малко от max (родителския възел) и всичко отдясно е повече от min (родителския възел).

### Възел на двоично дърво

Ето дефиницията на възела на двоичното дърво:

```js
class Node {
  constructor(value) {
    this.value = value;
    this.left = null;
    this.right = null;
  }
}
```

### Валидно двоично дърво за търсене (BST)

Двоичното дърво за търсене (BST) е двоично дърво, където всеки възел има стойност и всички възли в лявото поддърво имат стойности, по-малки от стойността на текущия възел, докато всички възли в дясното поддърво имат стойности, по-големи от стойността на текущия възел. Освен това лявото и дясното поддървета също трябва да бъдат валидни двоични дървета за търсене.

### Сигнатура на функцията

```js
/**
 * Returns a boolean indicating whether the binary tree is a valid binary search tree (BST).
 * @param {Node} root - The root node of the binary tree.
 * @param {number} min - The minimum value of the valid range for the current node's value.
 * @param {number} max - The maximum value of the valid range for the current node's value.
 * @returns {boolean} - A boolean indicating whether the binary tree is a valid binary search tree (BST).
 */
function isValidBST(
  root: Node,
  min: number = null,
  max: number = null
): boolean {}
```

### Примери

```js
// Input: root = [2,1,3]
// Output: true
// Explanation: The binary tree is as follows:
//     2
//    / \
//   1   3
// This is a valid binary search tree.

// Input: root = [5,1,4,null,null,3,6]
// Output: false
// Explanation: The binary tree is as follows:
//      5
//     / \
//    1   4
//       / \
//      3   6
// The node with a value of 4 has its left child with a value of 3, which violates the BST property, so it is not a valid BST.
```

### Подсказки

- Можете да решите този проблем, използвайки подход на обхождане в дълбочина.
- Използвайте рекурсия, за да изследвате лявото и дясното поддървета на всеки възел и да проверите дали стойността на текущия възел е в допустимия диапазон въз основа на позицията му в двоичното дърво за търсене.

## Решения

<details>
  <summary>Натиснете за решение</summary>

```js
class Node {
  constructor(value) {
    this.value = value;
    this.left = null;
    this.right = null;
  }
}

function isValidBST(root, min = null, max = null) {
  if (!root) {
    return true;
  }

  if (
    (min !== null && root.value <= min) ||
    (max !== null && root.value >= max)
  ) {
    return false;
  }

  return (
    isValidBST(root.left, min, root.value) &&
    isValidBST(root.right, root.value, max)
  );
}
```

### Обяснение

Решението на този проблем е да се използва подход на обхождане в дълбочина, за да се изследват рекурсивно лявото и дясното поддървета на всеки възел и да се провери дали стойността на текущия възел е в допустимия диапазон въз основа на позицията му в двоичното дърво за търсене.

- Проверяваме дали текущият възел е `null`. Ако е, връщаме `true`, защото празно дърво е валидно двоично дърво за търсене.
- Проверяваме дали стойността на текущия възел е по-малка или равна на стойността `min` или по-голяма или равна на стойността `max`. Ако е, връщаме `false`, защото стойността на текущия възел не е в допустимия диапазон въз основа на позицията му в двоичното дърво за търсене.
- Рекурсивно извикваме функцията `isValidBST` за лявото поддърво на текущия възел, като подаваме стойността `min` и стойността на текущия възел като `max`.
- Рекурсивно извикваме функцията `isValidBST` за дясното поддърво на текущия възел, като подаваме стойността на текущия възел като `min` и стойността `max`.
- Ако стойността на текущия възел е в допустимия диапазон и лявото и дясното поддървета са валидни двоични дървета за търсене, връщаме `true`. В противен случай връщаме `false`.

### Опитайте

Нека тестваме нашето решение със следното двоично дърво за търсене:

```js
/*

     8
    / \
   4   10
  / \
 2   6

*/
```

```js
const root = new Node(8);
const node4 = new Node(4); // left
const node10 = new Node(10); // right
const node2 = new Node(2); // left
const node6 = new Node(6); // right

root.left = node4;
root.right = node10;
node4.left = node2;
node4.right = node6;

console.log(isValidBST(root));
```

</details>

### Тестови случаи

```js
const { Node, isValidBST } = require('./validate-bst');

describe('isValidBST', () => {
  it('should return true for a valid binary search tree', () => {
    const root = new Node(8);
    const node4 = new Node(4);
    const node10 = new Node(10);
    const node2 = new Node(2);
    const node6 = new Node(6);

    root.left = node4;
    root.right = node10;
    node4.left = node2;
    node4.right = node6;

    const result = isValidBST(root);
    expect(result).toBe(true);
  });

  it('should return false for an invalid binary search tree', () => {
    const root = new Node(8);
    const node4 = new Node(4);
    const node10 = new Node(10);
    const node2 = new Node(2);
    const node12 = new Node(12);

    root.left = node4;
    root.right = node10;
    node4.left = node2;
    node4.right = node12;

    const result = isValidBST(root);
    expect(result).toBe(false);
  });
});

```
