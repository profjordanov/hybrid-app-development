# Предизвикателство: Рекурсивно обхождане в дълбочина

## Инструкции

Напишете функция, наречена `recDepthFirstTraversal`, която приема кореновия възел на двоично дърво като вход и връща масив, съдържащ възлите, посетени в ред на обхождане в дълбочина. Можете да използвате предишния урок като референция, но трябва да използвате рекурсия, за да решите този проблем.

Обхождането в дълбочина е алгоритъм, който започва от кореновия възел и изследва колкото е възможно по-далеч по всеки клон, преди да се върне назад. Възлите се посещават в реда, в който се срещат по време на обхождането.

Класът `Node` е предоставен за вас:

```js
class Node {
  constructor(data) {
    this.data = data;
    this.left = null;
    this.right = null;
  }
}
```

Можете да приемете, че двоичното дърво не е празно.

### Пример

```js
const root = new Node('a');
root.left = new Node('b');
root.right = new Node('c');
root.left.left = new Node('d');
root.left.right = new Node('e');
root.right.left = new Node('f');

depthFirstTraversal(root); // should return ['a', 'b', 'd', 'e', 'c', 'f']
```

### Подсказки

- Можете да имплементирате обхождането в дълбочина рекурсивно, като използвате помощна функция, която се извиква за лявото и дясното поддърво на текущия възел.
- Базовият случай е, когато възелът е `null`, в който случай просто се връщаме от функцията.

## Решения

<details>
  <summary>Натиснете за решение</summary>

```js
class Node {
  constructor(data) {
    this.data = data;
    this.left = null;
    this.right = null;
  }
}

function recDepthFirstTraversal(root) {
  const result = [];

  function traverse(node) {
    if (node !== null) {
      result.push(node.data);
      traverse(node.left);
      traverse(node.right);
    }
  }

  traverse(root);
  return result;
}
```

### Обяснение

- Инициализираме празен масив, наречен `result`, за да съхраним възлите, посетени при обхождането в дълбочина.
- Дефинираме помощна функция, наречена `traverse`, която приема възел като вход.
- Ако възелът не е `null`, добавяме данните на възела в масива `result`.
- Извикваме `traverse` за лявото поддърво на текущия възел.
- Извикваме `traverse` за дясното поддърво на текущия възел.
- Извикваме `traverse` за кореновия възел, за да започнем обхождането.
- Връщаме масива `result`.

</details>

### Тестови случаи

```js
const { Node, recDepthFirstTraversal } = require('./recursive-depth-traversal');

// Test tree:
//      a
//     / \
//    b   c
//   / \   \
//  d   e   f

const root = new Node('a');
root.left = new Node('b');
root.right = new Node('c');
root.left.left = new Node('d');
root.left.right = new Node('e');
root.right.left = new Node('f');

test('Depth First Traversal', () => {
  expect(depthFirstTraversal(root)).toEqual(['a', 'b', 'd', 'e', 'c', 'f']);
});
```
