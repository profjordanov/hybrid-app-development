# Обхождане в ширина (Breadth-First Traversal)

Сега нека разгледаме друг алгоритъм за обхождане на двоични дървета, наречен `Обхождане в ширина` (Breadth-First Traversal). За разлика от обхождането в дълбочина, което изследва колкото е възможно по-далеч по всеки клон, преди да се върне назад, обхождането в ширина изследва всички възли на текущото ниво на дълбочина, преди да премине към следващото ниво.

За да илюстрираме този алгоритъм, нека разгледаме същото двоично дърво, което използвахме в примера за обхождане в дълбочина:

<img src=".../../assets/images/breadth-first.png" width="500" alt="" />

При обхождането в ширина започваме от кореновия възел `a` и посещаваме неговите деца, `b` и `c`, по ред. След това слизаме на следващото ниво и посещаваме децата на `b` и `c`, които са `d`, `e` и `f`. Продължаваме този модел, като посещаваме всички възли на текущото ниво, преди да преминем на следващото ниво.

Така редът на обхождане в този пример ще бъде `a`, `b`, `c`, `d`, `e`, `f`.

За да имплементираме алгоритъма за обхождане в ширина, ще използваме структура от данни опашка (queue). Опашката е `FIFO` (First In First Out — Първи влязъл, първи излязъл) структура от данни, което означава, че първият възел, който добавим в опашката, ще бъде първият възел, който извадим от опашката. Ще започнем, като добавим кореновия възел в опашката и след това ще итерираме през опашката, добавяйки децата на всеки възел, докато ги посещаваме.

Нека имплементираме обхождането в ширина в JavaScript:

```js
class Node {
  constructor(data) {
    this.data = data;
    this.left = null;
    this.right = null;
  }
}

function breadthFirstTraversal(root) {
  if (!root) {
    return [];
  }

  const result = [];
  const queue = [];

  queue.push(root);

  while (queue.length > 0) {
    const current = queue.shift();
    result.push(current.data);

    if (current.left) {
      queue.push(current.left);
    }

    if (current.right) {
      queue.push(current.right);
    }
  }

  return result;
}

module.exports = {
  Node,
  breadthFirstTraversal,
};
```

В тази имплементация първо проверяваме дали `кореновият` възел съществува. Ако не съществува, връщаме празен масив.

След това създаваме масив `result` и масив `queue`. Добавяме `кореновия` възел в опашката.

След това стартираме цикъл `while`, който работи, докато масивът `queue` има дължина по-голяма от `0`.

Вътре в цикъла извличаме първия възел от опашката (използвайки `shift()`) и го добавяме към масива `result`.

След това добавяме лявото и дясното дете на текущия възел в опашката, ако съществуват. Продължаваме този процес, докато масивът `queue` стане празен, и след това връщаме масива `result`.

## Използване на класа Queue

Сега нека рефакторираме този код, за да използваме класа `Queue`. Можете да направите това като предизвикателство или можете да погледнете кода по-долу. Също ще добавя тестове, за да се уверя, че кодът работи правилно.

```js
const Queue = require('./queue');

class Node {
  constructor(data) {
    this.data = data;
    this.left = null;
    this.right = null;
  }
}

function breadthFirstTraversal(root) {
  if (!root) {
    return [];
  }

  const result = [];
  const queue = new Queue();

  queue.enqueue(root);

  while (!queue.isEmpty()) {
    const current = queue.dequeue();
    result.push(current.data);

    if (current.left) {
      queue.enqueue(current.left);
    }

    if (current.right) {
      queue.enqueue(current.right);
    }
  }

  return result;
}

module.exports = {
  Node,
  breadthFirstTraversal,
};
```

В този рефакториран код използвахме класа `Queue` вместо стандартен масив за структурата от данни опашка. Също използвахме метода `isEmpty()` вместо да проверяваме дължината на масива. След това добавихме тестове, за да се уверим, че алгоритъмът за обхождане в ширина работи правилно.

## Тестови случаи

```js
describe('Breadth-First Traversal', () => {
  test('Should perform breadth-first traversal on the binary tree', () => {
    // Create a binary tree:      a
    //                          /   \
    //                         b     c
    //                        / \    /
    //                       d   e  f

    const root = new Node('a');
    const nodeB = new Node('b');
    const nodeC = new Node('c');
    const nodeD = new Node('d');
    const nodeE = new Node('e');
    const nodeF = new Node('f');

    root.left = nodeB;
    root.right = nodeC;
    nodeB.left = nodeD;
    nodeB.right = nodeE;
    nodeC.left = nodeF;

    expect(breadthFirstTraversal(root)).toEqual(['a', 'b', 'c', 'd', 'e', 'f']);
  });

  test('Should return an empty array for an empty tree', () => {
    expect(breadthFirstTraversal(null)).toEqual([]);
  });

  test('Should handle a tree with only the root node', () => {
    const root = new Node('root');
    expect(breadthFirstTraversal(root)).toEqual(['root']);
  });
});
```

Няма наистина лесен начин да се реши този проблем рекурсивно без използване на структура от данни опашка. Бихте могли да използвате стек, но ще трябва да следите текущото ниво на дървото и следващото ниво. Това би направило кода по-сложен и по-малко ефективен. Така че, по мое мнение, това е най-добрият начин за обхождане в ширина.
