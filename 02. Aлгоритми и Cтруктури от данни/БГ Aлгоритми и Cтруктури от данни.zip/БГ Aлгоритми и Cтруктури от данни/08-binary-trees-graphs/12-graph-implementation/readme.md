# Имплементация на граф

Сега ще създадем клас за граф в JavaScript. Отново можете да направите това на всеки език, който желаете. Ще използваме списък на съседство под формата на обект.

### Конструктор

```JavaScript
class Graph {
  constructor() {
    this.adjacencyList = {};
  }
}
```

### Метод `addVertex`

Ще имаме метод, наречен `addVertex`, който приема име на връх като параметър. Ще зададем списъка на съседство за този връх да бъде празен масив.

```JavaScript
addVertex(vertex) {
  this.adjacencyList[vertex] = [];
}
```

### Метод `addEdge`

Също така ще имаме метод, наречен `addEdge`, който приема два върха като параметри. Ще намерим в списъка на съседство ключа за vertex1 и ще добавим vertex2 в масива. След това ще намерим в списъка на съседство ключа за vertex2 и ще добавим vertex1 в масива.

```JavaScript
addEdge(vertex1, vertex2) {
  this.adjacencyList[vertex1].push(vertex2);
  this.adjacencyList[vertex2].push(vertex1);
}
```

### Метод `printAdjacencyList`

Нека създадем метод, който да ни даде визуално представяне на нашия списък на съседство, за да можем да видим всички върхове и техните ребра/връзки.

```JS
printAdjacencyList() {
    for (const vertex in this.adjacencyList) {
      console.log(`${vertex} -> ${this.adjacencyList[vertex].join(', ')}`);
    }
  }
```

Нека опитаме да добавим няколко върхa и ребра.

```JS
g.addVertex('Tokyo');
g.addVertex('Dallas');
g.addVertex('Aspen');

g.addEdge('Tokyo', 'Dallas');
g.addEdge('Dallas', 'Aspen');
g.addEdge('Aspen', 'Tokyo');

g.printAdjacencyList();
```

Когато стартирате, трябва да видите нещо подобно:

```text
Tokyo -> Dallas, Aspen
Dallas -> Tokyo, Aspen
Aspen -> Dallas, Tokyo
```

### Метод `removeEdge`

Също ще имаме метод, наречен `removeEdge`, който приема два върха като параметри. Ще преназначим ключа за vertex1 да бъде масив, който не съдържа vertex2. Ще преназначим ключа за vertex2 да бъде масив, който не съдържа vertex1.

```JavaScript
removeEdge(vertex1, vertex2) {
  this.adjacencyList[vertex1] = this.adjacencyList[vertex1].filter(
    (v) => v !== vertex2
  );
  this.adjacencyList[vertex2] = this.adjacencyList[vertex2].filter(
    (v) => v !== vertex1
  );
}
```

### Метод `removeVertex`

Също ще имаме метод, наречен `removeVertex`, който приема връх като параметър. Ще циклим, докато има други върхове в списъка на съседство за този връх. Вътре в цикъла ще извикаме `removeEdge` и ще подадем върха, който премахваме, и всички стойности в списъка на съседство за този връх. След това ще изтрием ключа в списъка на съседство за този връх.

```JavaScript
removeVertex(vertex) {
  while (this.adjacencyList[vertex].length) {
    const adjacentVertex = this.adjacencyList[vertex].pop();
    this.removeEdge(vertex, adjacentVertex);
  }
  delete this.adjacencyList[vertex];
}
```

## Опитайте

Нека тестваме нашия клас за граф.

```JavaScript
g.addVertex('Tokyo');
g.addVertex('Dallas');
g.addVertex('Aspen');
g.addEdge('Tokyo', 'Dallas');
g.addEdge('Dallas', 'Aspen');
g.addEdge('Tokyo', 'Aspen');

g.removeEdge('Dallas', 'Aspen');
g.removeVertex('Aspen');

g.printAdjacencyList();
```

Създадохме граф с три върха. Добавихме ребра между Tokyo и Dallas, Dallas и Aspen, и Tokyo и Aspen. Премахнахме реброто между Dallas и Aspen. Премахнахме върха Aspen.

Трябва да видите:

```text
Tokyo -> Dallas
Dallas -> Tokyo
```

## Тестови случаи

```JavaScript
describe('Graph', () => {
  let g;

  beforeEach(() => {
    g = new Graph();
  });

  test('Should add vertices to the graph', () => {
    g.addVertex('Tokyo');
    g.addVertex('Dallas');
    g.addVertex('Aspen');

    expect(g.adjacencyList).toEqual({
      Tokyo: [],
      Dallas: [],
      Aspen: [],
    });
  });

  test('Should add edges between vertices in the graph', () => {
    g.addVertex('Tokyo');
    g.addVertex('Dallas');
    g.addVertex('Aspen');
    g.addEdge('Tokyo', 'Dallas');
    g.addEdge('Dallas', 'Aspen');

    expect(g.adjacencyList).toEqual({
      Tokyo: ['Dallas'],
      Dallas: ['Tokyo', 'Aspen'],
      Aspen: ['Dallas'],
    });
  });

  test('Should remove edges between vertices in the graph', () => {
    g.addVertex('Tokyo');
    g.addVertex('Dallas');
    g.addVertex('Aspen');
    g.addEdge('Tokyo', 'Dallas');
    g.addEdge('Dallas', 'Aspen');
    g.removeEdge('Dallas', 'Aspen');

    expect(g.adjacencyList).toEqual({
      Tokyo: ['Dallas'],
      Dallas: ['Tokyo'],
      Aspen: [],
    });
  });

  test('Should remove vertices and associated edges from the graph', () => {
    g.addVertex('Tokyo');
    g.addVertex('Dallas');
    g.addVertex('Aspen');
    g.addEdge('Tokyo', 'Dallas');
    g.addEdge('Dallas', 'Aspen');
    g.removeVertex('Aspen');

    expect(g.adjacencyList).toEqual({
      Tokyo: ['Dallas'],
      Dallas: ['Tokyo'],
    });
  });
});
```

В следващия урок ще разгледаме обхождане на графи.
