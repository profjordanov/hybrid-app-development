# Предизвикателство: Обхождане на граф в дълбочина

## Инструкции

Напишете функция, наречена `depthFirstTraversal`, която извършва обхождане в дълбочина на граф, започвайки от определен връх, и връща масив, съдържащ посетените върхове в реда, в който са били обходени. Използвайте класа `Graph`, както и класа `Stack` от предишните уроци.

## Сигнатура на функцията

```js
/**
 * Returns an array containing the vertices visited in the order they were traversed.
 * @param {Graph} graph - The graph to traverse.
 * @param {string} startingVertex - The vertex to start the traversal from.
 * @returns {string[]} - The vertices visited in the order they were traversed.
 */
function depthFirstTraversal(graph: Graph, startingVertex: string): string[];
```

## Пример

```js
// Example Graph
// A --- B
// |     |
// |     |
// C --- D
// |     |
// |     |
// E --- F

const graph = new Graph();

// Add vertices
graph.addVertex('A');
graph.addVertex('B');
graph.addVertex('C');
graph.addVertex('D');
graph.addVertex('E');
graph.addVertex('F');

// Add edges
graph.addEdge('A', 'B');
graph.addEdge('A', 'C');
graph.addEdge('B', 'D');
graph.addEdge('C', 'D');
graph.addEdge('C', 'E');
graph.addEdge('D', 'F');
graph.addEdge('E', 'F');

depthFirstTraversal(g, 'A');
// ['A', 'C', 'E', 'F', 'D', 'B'];
```

## Подсказки

- Класът `Graph` има свойство `adjacencyList`, което съхранява върховете и техните съседи.
- Класът `Stack` има метод `push`, който добавя елемент на върха на стека, и метод `pop`, който премахва горния елемент от стека.
- Използвайте масив за резултати, за да съхраните посетените върхове в реда, в който са били обходени

## Решения

<details>
  <summary>Натиснете за решение</summary>

#### Използвайки списък на съседство:

```js
function depthFirstTraversal(graph, startingVertex) {
  if (!graph.adjacencyList[startingVertex]) {
    return [];
  }

  const visited = {};
  const stack = [startingVertex];
  const result = [];

  visited[startingVertex] = true;

  while (stack.length) {
    const currentVertex = stack.pop();
    result.push(currentVertex);

    graph.adjacencyList[currentVertex].forEach((neighbor) => {
      if (!visited[neighbor]) {
        visited[neighbor] = true;
        stack.push(neighbor);
      }
    });
  }

  return result;
}
```

### Обяснение

- Проверяваме дали началният връх съществува в списъка на съседство на графа. Ако не съществува, връщаме празен масив.
- Инициализираме празен обект `visited`, за да съхраним посетените върхове.
- Инициализираме стек с началния връх.
- Инициализираме празен масив `result`, за да съхраним посетените върхове в реда, в който са били обходени.
- Маркираме началния връх като посетен.
- Докато стекът не е празен:
  - Извличаме връх от стека и го добавяме в масива `result`.
  - За всеки съсед на върха:
    - Ако съседът не е бил посетен:
      - Маркираме съседа като посетен.
      - Добавяме съседа в стека.
- Връщаме масива `result`.

</details>

## Тестови случаи

```js
describe('Graph Depth-First Traversal', () => {
  test('should perform depth-first traversal correctly', () => {
    const g = new Graph();
    g.addVertex('A');
    g.addVertex('B');
    g.addVertex('C');
    g.addVertex('D');
    g.addVertex('E');
    g.addVertex('F');
    g.addVertex('G');

    g.addEdge('A', 'B');
    g.addEdge('A', 'C');
    g.addEdge('B', 'D');
    g.addEdge('C', 'E');
    g.addEdge('D', 'E');
    g.addEdge('D', 'F');
    g.addEdge('E', 'G');
    g.addEdge('F', 'G');

    const result = depthFirstTraversal(g, 'A').sort();
    const expected = ['A', 'B', 'C', 'D', 'E', 'F', 'G'].sort();
    expect(result).toEqual(expected);
  });

  test('should handle loops correctly', () => {
    const g = new Graph();
    g.addVertex('X');
    g.addVertex('Y');
    g.addVertex('Z');

    g.addEdge('X', 'Y');
    g.addEdge('Y', 'Z');
    g.addEdge('Z', 'X');

    const result = depthFirstTraversal(g, 'X').sort();
    const expected = ['X', 'Y', 'Z'].sort();
    expect(result).toEqual(expected);
  });

  test('should return an empty array for an empty graph', () => {
    const g = new Graph();

    expect(depthFirstTraversal(g, 'A')).toEqual([]);
  });
});
```
