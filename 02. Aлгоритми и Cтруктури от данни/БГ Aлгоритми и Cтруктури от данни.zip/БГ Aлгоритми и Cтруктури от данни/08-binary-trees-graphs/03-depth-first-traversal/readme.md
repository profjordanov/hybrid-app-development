# Обхождане в дълбочина (Depth First Traversal)

Сега ще навлезем в някои алгоритми, свързани с двоични дървета. Този се нарича `Обхождане в дълбочина` (Depth First Traversal). Това е алгоритъм за обхождане, при който алгоритъмът започва от `кореновия` възел, който знаем, че е този в горната част на дървото без родител, и изследва колкото е възможно по-далеч по всеки клон, преди да се върне назад.

Ако погледнем следното дърво:

<img src=".../../assets/images/depth-first.png" width="500" alt="" />

Ще започнем от `a` и след това ще отидем до `b`. Оттук ще отидем до `d`, защото отиваме колкото е възможно по-далеч по всеки клон, преди да се върнем назад. `d` е най-далеч, до което можем да стигнем по този път, защото е `листов възел`, което означава, че няма деца. Сега можем да преминем към `e`. Ако `e` имаше дете, щяхме да слезем надолу, но тъй като няма, ще преминем към `c`. От `c` можем да слезем в дълбочина до `f`.

Така този ред ще бъде `a`, `b`, `d`, `e`, `c`, `f`.

Сега искаме да имплементираме този алгоритъм. Ще използваме `стек`, за да имплементираме този алгоритъм, защото искаме да следим кои възли сме посетили. Помнете, че стекът е `LIFO` структура от данни, което означава `Last In First Out` (Последен влязъл, първи излязъл). Така последният възел, който посетим, ще бъде първият възел, който извадим от стека. Когато възел бъде извлечен или премахнат от стека, можем да кажем, че този възел е бил `посетен`. Когато възел бъде извлечен от стека, той ще бъде поставен в променлива, наречена `current`. След това ще проверим дали `current` има дясно дете. Ако има, ще го добавим към стека. Ако няма, ще проверим дали има ляво дете. Ако има, ще го добавим към стека. Ако няма, ще извлечем следващия възел от стека и ще повторим процеса.

Нека имплементираме това в JavaScript. Ще използваме същия клас `Node`, който използвахме в предишния урок. Първо ще използваме стандартен масив като наш стек, но след това искам да имплементираме класа `Stack`, който създадохме преди няколко урока.

```js
class Node {
  constructor(data) {
    this.data = data;
    this.left = null;
    this.right = null;
  }
}

function depthFirstTraversal(root) {
  if (!root) {
    return [];
  }

  const result = [];
  const stack = [];

  stack.push(root);

  while (stack.length > 0) {
    const current = stack.pop();
    result.push(current.data);

    if (current.right) {
      stack.push(current.right);
    }

    if (current.left) {
      stack.push(current.left);
    }
  }

  return result;
}

module.exports = {
  Node,
  depthFirstTraversal,
};
```

Направихме точно това, което описах по-горе. Първо проверяваме дали `кореновият` възел съществува. Ако не съществува, връщаме празен масив.

След това създаваме масив `result` и масив `stack`. После добавяме `кореновия` възел в стека.

След това започваме цикъл `while`, който ще работи, докато масивът `stack` има дължина по-голяма от `0`. Вътре в цикъла `while` извличаме последния възел от стека и го добавяме към масива `result`.

След това проверяваме дали `текущият` възел има дясно дете. Ако има, го добавяме към стека. След това проверяваме дали `текущият` възел има ляво дете. Ако има, го добавяме към стека.

Повтаряме процеса, докато масивът `stack` достигне дължина `0`. След това връщаме масива `result`.

## Използване на класа Stack

Сега нека рефакторираме този код, за да използваме класа `Stack`, който създадохме преди няколко урока. Можете да направите това като предизвикателство или можете да погледнете кода по-долу. Също ще добавя тест, за да се уверя, че кодът работи.

```js
const Stack = require('./stack');

class Node {
  constructor(data) {
    this.data = data;
    this.left = null;
    this.right = null;
  }
}

function depthFirstTraversal(root) {
  if (!root) {
    return [];
  }

  const result = [];
  const stack = new Stack();

  stack.push(root);

  while (!stack.isEmpty()) {
    const current = stack.pop();
    result.push(current.data);

    if (current.right) {
      stack.push(current.right);
    }

    if (current.left) {
      stack.push(current.left);
    }
  }

  return result;
}
```

Този код е много подобен, с изключение на това, че използвахме предварително дефиниран клас `Stack` вместо стандартен масив. Също използвахме метода `isEmpty()` вместо да проверяваме дължината на масива.

## Тестови случаи

```js
const { Node, depthFirstTraversal } = require('./depth-first-traversal');

describe('Depth First Traversal', () => {
  test('Should perform depth-first traversal on the binary tree', () => {
    // Create a binary tree:      a
    //                          /   \
    //                         b     c
    //                        / \    /
    //                       d   e  f

    const root = new Node('a');
    const nodeB = new Node('b');
    const nodeC = new Node('c');
    const nodeD = new Node('d');
    const nodeE = new Node('e');
    const nodeF = new Node('f');

    root.left = nodeB;
    root.right = nodeC;
    nodeB.left = nodeD;
    nodeB.right = nodeE;
    nodeC.left = nodeF;

    expect(depthFirstTraversal(root)).toEqual(['a', 'b', 'd', 'e', 'c', 'f']);
  });

  test('Should return an empty array for an empty tree', () => {
    expect(depthFirstTraversal(null)).toEqual([]);
  });

  test('Should handle a tree with only the root node', () => {
    const root = new Node('root');
    expect(depthFirstTraversal(root)).toEqual(['root']);
  });
});
```
