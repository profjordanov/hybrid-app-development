# Предизвикателство: Обхождане на граф в ширина

## Инструкции

Напишете функция, наречена `breadthFirstTraversal`, която извършва обхождане в ширина на граф, започвайки от определен връх, и връща масив, съдържащ посетените върхове в реда, в който са били обходени. Използвайте класа `Queue` от предишните уроци.

## Сигнатура на функцията

```js
/**
 * Performs a Breadth First Traversal of a graph.
 * @param {Graph} graph - The graph to traverse.
 * @param {string} startingVertex - The vertex to start the traversal from.
 * @returns {string[]} - The vertices visited in the order they were traversed.
 */
function breadthFirstTraversal(graph: Graph, startingVertex: string): string[];
```

## Пример

```js
// Example Graph
// A --- B
// |     |
// |     |
// C --- D
// |     |
// |     |
// E --- F

const graph = new Graph();

graph.addVertex('A');
graph.addVertex('B');
graph.addVertex('C');
graph.addVertex('D');
graph.addVertex('E');
graph.addVertex('F');

graph.addEdge('A', 'B');
graph.addEdge('A', 'C');
graph.addEdge('B', 'D');
graph.addEdge('C', 'D');
graph.addEdge('C', 'E');
graph.addEdge('D', 'F');
graph.addEdge('E', 'F');

const result = breadthFirstTraversal(graph, 'A');

console.log(result);
// [ 'A', 'B', 'C', 'D', 'E', 'F' ]
```

## Подсказки

- Можете да използвате предоставения клас `Queue`, за да следите върховете, които трябва да бъдат посетени в ред на обхождане в ширина.
- Започнете, като добавите `startingVertex` в опашката и го маркирате като посетен.
- Използвайте множество (set) за посетените, за да следите посетените върхове и да избегнете добавянето на един и същи връх повече от веднъж.
- В цикъла за обхождане извлечете връх от опашката, добавете го към масива с резултати и добавете в опашката всичките му съседи, които все още не са били посетени.

## Решения

<details>
  <summary>Натиснете за решение</summary>

```js
function breadthFirstTraversal(graph, startingVertex) {
  const visited = new Set();
  const result = [];
  const queue = new Queue();

  queue.enqueue(startingVertex);
  visited.add(startingVertex);

  while (!queue.isEmpty()) {
    const currentVertex = queue.dequeue();
    result.push(currentVertex);

    for (const neighbor of graph.adjacencyList[currentVertex]) {
      if (!visited.has(neighbor)) {
        queue.enqueue(neighbor);
        visited.add(neighbor);
      }
    }
  }

  return result;
}
```

### Обяснение

- Създаваме множество `visited`, за да следим посетените върхове, масив `result`, за да съхраним посетените върхове в реда, в който са били обходени, и `queue`, за да следим върховете, които трябва да бъдат посетени в ред на обхождане в ширина.
- Добавяме `startingVertex` в опашката и го маркираме като посетен.
- В цикъл извличаме връх от опашката, добавяме го към масива с резултати и добавяме в опашката всичките му съседи, които все още не са били посетени.
- Продължаваме този процес, докато опашката стане празна.
- Връщаме масива с резултати.

</details>

## Тест

```js
const Graph = require('./graph');
const Queue = require('./queue');
const breadthFirstTraversal = require('./graph-breadth-first');

describe('Breadth First Traversal', () => {
  it('should traverse a graph in breadth-first order', () => {
    const graph = new Graph();

    graph.addVertex('A');
    graph.addVertex('B');
    graph.addVertex('C');
    graph.addVertex('D');
    graph.addVertex('E');
    graph.addVertex('F');
    graph.addVertex('G');

    graph.addEdge('A', 'B');
    graph.addEdge('A', 'C');
    graph.addEdge('B', 'D');
    graph.addEdge('B', 'E');
    graph.addEdge('C', 'F');
    graph.addEdge('C', 'G');

    const result = breadthFirstTraversal(graph, 'A');
    expect(result).toEqual(['A', 'B', 'C', 'D', 'E', 'F', 'G']);
  });

  it('should handle disconnected components in the graph', () => {
    const graph = new Graph();

    graph.addVertex('A');
    graph.addVertex('B');
    graph.addVertex('C');
    graph.addVertex('D');

    graph.addEdge('A', 'B');
    graph.addEdge('C', 'D');

    const result = breadthFirstTraversal(graph, 'A');
    expect(result).toEqual(['A', 'B']);
  });
});

```
