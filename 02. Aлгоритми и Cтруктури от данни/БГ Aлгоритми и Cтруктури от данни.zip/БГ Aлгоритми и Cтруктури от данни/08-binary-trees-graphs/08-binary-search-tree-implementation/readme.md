# Имплементация на двоично дърво за търсене

В този урок ще имплементираме двоично дърво за търсене в JavaScript. Ще започнем, като създадем клас `Node`, който ще представлява всеки възел в дървото. Всеки възел ще има стойност `value`, свойство `left` и свойство `right`. Свойствата `left` и `right` ще сочат към други възли или ще бъдат `null`, ако няма ляво или дясно дете.

```js
class Node {
  constructor(value) {
    this.value = value;
    this.left = null;
    this.right = null;
  }
}
```

След това ще създадем клас `BinarySearchTree`. Този клас ще има свойство `root`, което ще сочи към кореновия възел на дървото. Първоначално кореновият възел ще бъде `null`.

```js
class BinarySearchTree {
  constructor() {
    this.root = null;
  }
}
```

## Метод `insert`

След това ще имплементираме метода `insert`. Този метод ще приема стойност като аргумент и ще вмъква нов възел с тази стойност в дървото.

```js
insert(value) {
  const newNode = new Node(value);

  if (this.root === null) {
    this.root = newNode;
  } else {
    let currentNode = this.root;

    while (true) {
      if (value < currentNode.value) {
        if (!currentNode.left) {
          currentNode.left = newNode;
          return this;
        }

        currentNode = currentNode.left;
      } else {

        if (!currentNode.right) {
          currentNode.right = newNode;
          return this;
        }

        currentNode = currentNode.right;
      }
    }
  }
}
```

Започваме, като създаваме нов възел с дадената стойност.

Ако дървото е празно, задаваме кореновия възел да бъде новия възел. В противен случай започваме от кореновия възел и обхождаме дървото, докато намерим възел без ляво или дясно дете.

Ако новата стойност е по-малка от стойността на текущия възел, преминаваме към лявото дете. Ако новата стойност е по-голяма или равна на стойността на текущия възел, преминаваме към дясното дете.

Продължаваме този процес, докато намерим възел без ляво или дясно дете, и тогава вмъкваме новия възел на тази позиция.

## Метод `lookup`

След това ще имплементираме метода `lookup`. Този метод ще приема стойност като аргумент и ще връща възела с тази стойност, ако съществува в дървото. Ако стойността не съществува в дървото, ще върнем `null`.

```js
lookup(value) {
    let currentNode = this.root;

    if (!currentNode) {
      return null;
    }

    while (currentNode) {
      if (value < currentNode.value) {
        currentNode = currentNode.left;
      }
      else if (value > currentNode.value) {
        currentNode = currentNode.right;
      }
      else if (value === currentNode.value) {
        return currentNode;
      }
    }

    return null;
  }
```

Задаваме текущия възел да бъде кореновият възел.

Ако дървото е празно, връщаме `null`. В противен случай обхождаме дървото, докато намерим възел с дадената стойност.

Ако стойността е по-малка от стойността на текущия възел, преминаваме към лявото дете. Ако стойността е по-голяма от стойността на текущия възел, преминаваме към дясното дете. Ако стойността е равна на стойността на текущия възел, връщаме текущия възел.

Ако стигнем до възел, който няма ляво или дясно дете, връщаме `null`.

## Метод `remove`

След това ще имплементираме метода `remove`. Този метод ще приема стойност като аргумент и ще премахва възела с тази стойност от дървото.

```js
remove(value) {
  const removeNode = (node, value) => {
    if (node === null) {
      return null;
    }

    if (value < node.value) {
      node.left = removeNode(node.left, value);
      return node;
    }
    else if (value > node.value) {
      node.right = removeNode(node.right, value);
      return node;
    }
    else {
      // Case 1: Node with no child or only one child
      if (node.left === null) {
        return node.right;
      } else if (node.right === null) {
        return node.left;
      }

      // Case 2: Node with two children
      // Find the smallest value in the right subtree (successor)
      let tempNode = node.right;
      while (tempNode.left !== null) {
        tempNode = tempNode.left;
      }

      // Case 3: Node is the root node
      // Replace the node's value with the successor's value
      node.value = tempNode.value;

      node.right = removeNode(node.right, tempNode.value);
      return node;
    }
  };

  // Start at the root
  this.root = removeNode(this.root, value);
}
```

Този е доста труден. Започваме, като създаваме помощна функция, наречена `removeNode`. Тази функция ще приема възел и стойност като аргументи и ще връща възелa с дадената стойност, премахнат от дървото.

Ако възелът е `null`, връщаме `null`. В противен случай обхождаме дървото, докато намерим възела с дадената стойност.

Ако стойността е по-малка от стойността на текущия възел, преминаваме към лявото дете. Ако стойността е по-голяма от стойността на текущия възел, преминаваме към дясното дете. Ако стойността е равна на стойността на текущия възел, намерили сме възела, който искаме да премахнем.

Има три случая, които трябва да разгледаме:

1. Възелът няма деца или има само едно дете
2. Възелът има две деца
3. Възелът е кореновият възел

### Случай 1: Възел без деца или с едно дете

Ако възелът няма деца или има само едно дете, можем просто да върнем лявото или дясното дете на възела. Това ще премахне възела от дървото.

### Случай 2: Възел с две деца

Ако възелът има две деца, трябва да намерим най-малката стойност в дясното поддърво. Тази стойност ще бъде наследникът на възела. Ще заменим стойността на възела със стойността на наследника и след това ще премахнем наследника от дървото.

### Случай 3: Възелът е кореновият възел

Ако възелът е кореновият възел, трябва да заменим кореновия възел с наследника. Ще заменим стойността на кореновия възел със стойността на наследника и след това ще премахнем наследника от дървото.

## Метод `printTree`

Накрая ще имплементираме метода `printTree`. Този метод ще отпечата дървото в четим формат.

```js
 printTree() {
    const printNode = (node) => {
      if (node === null) {
        return;
      }
      printNode(node.left);
      console.log(node.value);
      printNode(node.right);
    };
    printNode(this.root);
  }
```

## Анализ на времето за изпълнение на BST

BST са много ефективни структури от данни. Те са много бързи при вмъкване, търсене и изтриване на стойности и имат време за изпълнение O(log n) за всяка от тези операции, с изключение на отпечатването на дървото, което има време за изпълнение O(n). Това е, защото трябва да посетим всеки възел в дървото, за да го отпечатаме.

| Операция  | Време за изпълнение |
| --------- | ------------------- |
| Вмъкване  | O(log n)            |
| Търсене   | O(log n)            |
| Изтриване | O(log n)            |
| Печат     | O(n)                |

## Пример за двоично дърво за търсене

<img src="../../assets/images/binary-search-tree1.png" width="600" />

```js
const bst = new BinarySearchTree();
bst.insert(9);
bst.insert(4);
bst.insert(11);
bst.insert(2);
bst.insert(7);
bst.insert(15);
bst.insert(5);
bst.insert(8);
```

Това ще създаде дървото.

Можем да използваме метода `lookup`, за да намерим възел в дървото. Нека намерим възела със стойност 4 и го изведем.

```js
console.log(bst.lookup(4));
```

Това ще изведе следното:

```js
{
  value: 4,
  left: { value: 2, left: null, right: null },
  right: { value: 7, left: [Node], right: [Node] }
}
```

Можете да видите, че възелът със стойност 4 има ляво дете със стойност 2 и дясно дете със стойност 7.

Нека премахнем възела със стойност 7 от дървото.

```js
bst.remove(7);
```

Сега потърсете 4 отново:

```js
console.log(bst.lookup(4));
```

Това ще изведе следното:

```js
{
  value: 4,
  left: { value: 2, left: null, right: null },
  right: { value: 8, left: [Node], right: null }
}
```

Можете да видите, че възелът със стойност 4 сега има дясно дете със стойност 8 вместо 7. Така че по същество замени възела с този, който беше от дясната му страна.

Нека отпечатаме дървото, за да се уверим, че изглежда като това, което създадохме.

```js
bst.printTree();
```

Това ще го отпечата в ред минус възела със стойност 7, който премахнахме.

```
2
4
5
8
9
11
15
```

Знам, че това може да е много подтискащо, но не очаквайте да овладеете това за един ден. Нужно е време и практика. Препоръчвам ви да прегледате тази статия отново и да се опитате да я разберете по-добре. Също препоръчвам да опитате да имплементирате тази структура от данни сами, както и други, без да гледате видеата или документацията.

### Тестови случаи

Ето тестовия пакет, който можете да използвате за структурата от данни двоично дърво за търсене.

```js
const { Node, BinarySearchTree } = require('./binary-search-tree');

describe('BinarySearchTree', () => {
  let bst;

  beforeEach(() => {
    bst = new BinarySearchTree();
  });

  test('should insert values correctly', () => {
    bst.insert(10);
    bst.insert(5);
    bst.insert(15);
    bst.insert(2);

    expect(bst.root.value).toBe(10);
    expect(bst.root.left.value).toBe(5);
    expect(bst.root.right.value).toBe(15);
    expect(bst.root.left.left.value).toBe(2);
  });

  test('should find existing nodes using lookup', () => {
    bst.insert(10);
    bst.insert(5);
    bst.insert(15);

    expect(bst.lookup(10).value).toBe(10);
    expect(bst.lookup(5).value).toBe(5);
    expect(bst.lookup(15).value).toBe(15);
  });

  test('should return null for non-existing nodes using lookup', () => {
    bst.insert(10);
    bst.insert(5);
    bst.insert(15);

    expect(bst.lookup(2)).toBeNull();
    expect(bst.lookup(8)).toBeNull();
    expect(bst.lookup(20)).toBeNull();
  });

  test('should remove nodes correctly', () => {
    bst.insert(10);
    bst.insert(5);
    bst.insert(15);
    bst.insert(2);
    bst.insert(7);

    bst.remove(2);
    expect(bst.lookup(2)).toBeNull();

    bst.remove(5);
    expect(bst.lookup(5)).toBeNull();

    bst.remove(15);
    expect(bst.lookup(15)).toBeNull();

    bst.remove(10);
    expect(bst.lookup(10)).toBeNull();

    bst.remove(7);
    expect(bst.lookup(7)).toBeNull();
  });

  test('should handle removing root node correctly', () => {
    bst.insert(10);
    bst.insert(5);
    bst.insert(15);

    bst.remove(10);
    expect(bst.root.value).toBe(15);
  });

  test('should print tree in-order', () => {
    const consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {}); // Spy on console.log and mock the implementation

    const bst = new BinarySearchTree();
    bst.insert(8);
    bst.insert(3);
    bst.insert(10);
    bst.insert(1);
    bst.insert(6);
    bst.insert(14);
    bst.insert(4);
    bst.insert(7);
    bst.insert(13);

    bst.printTree();

    // Expect the console.log to be called with the correct values in in-order traversal
    expect(consoleSpy).toHaveBeenNthCalledWith(1, 1);
    expect(consoleSpy).toHaveBeenNthCalledWith(2, 3);
    expect(consoleSpy).toHaveBeenNthCalledWith(3, 4);
    expect(consoleSpy).toHaveBeenNthCalledWith(4, 6);
    expect(consoleSpy).toHaveBeenNthCalledWith(5, 7);
    expect(consoleSpy).toHaveBeenNthCalledWith(6, 8);
    expect(consoleSpy).toHaveBeenNthCalledWith(7, 10);
    expect(consoleSpy).toHaveBeenNthCalledWith(8, 13);
    expect(consoleSpy).toHaveBeenNthCalledWith(9, 14);

    // Restore the original console.log implementation
    consoleSpy.mockRestore();
  });
});
```
