# Предизвикателство: Максимална дълбочина на двоично дърво

## Инструкции

Напишете функция, наречена `maxDepth`, която приема корена на двоично дърво като вход и връща максималната дълбочина на дървото. Максималната дълбочина е дефинирана като броя на възлите по най-дългия път от кореновия възел надолу до най-далечния листов възел.

### Сигнатура на функцията

```js
/**
 * Returns the maximum depth of the binary tree.
 * @param {Node} root - The root node of the binary tree.
 * @returns {number} - The maximum depth of the binary tree.
 */
function maxDepth(root: Node): number;) {}
```

### Примери

```js
// Explanation: The binary tree is as follows:
//     3
//    / \
//   9  20
//     /  \
//    15   7
// The maximum depth is 3, which is the path 3 -> 20 -> 7.

// Explanation: The binary tree is as follows:
//     1
//      \
//       2
// The maximum depth is 2, which is the path 1 -> 2.

// Input: root = []
// Output: 0
// Explanation: An empty tree has a maximum depth of 0.
```

### Подсказки

- Можете да решите този проблем, използвайки подход на обхождане в дълбочина.
- Използвайте рекурсия, за да изследвате лявото и дясното поддървета на всеки възел и да върнете максималната дълбочина между тях.

### Възел на двоично дърво

Ето дефиницията на възела на двоичното дърво:

```js
class Node {
  constructor(value) {
    this.value = value;
    this.left = null;
    this.right = null;
  }
}
```

## Решения

<details>
  <summary>Натиснете за решение</summary>

```js
class Node {
  constructor(val) {
    this.val = val;
    this.left = null;
    this.right = null;
  }
}

function maxDepth(root) {
  if (!root) {
    return 0;
  }

  const leftDepth = maxDepth(root.left);
  const rightDepth = maxDepth(root.right);

  return Math.max(leftDepth, rightDepth) + 1;
}
```

### Обяснение

- Проверяваме дали кореновият възел е `null`. Ако е, връщаме `0`, тъй като дървото е празно.
- Рекурсивно изчисляваме максималната дълбочина на лявото и дясното поддървета на текущия възел.
- Връщаме максималната дълбочина между лявото и дясното поддървета плюс `1`, за да отчетем текущия възел.

</details>

### Тестови случаи

```js
const { Node, maxDepth } = require('./maximum-depth');

describe('Binary Tree Maximum Depth', () => {
  test('Should calculate the maximum depth of a binary tree', () => {
    // Create the binary tree:    3
    //                           / \
    //                          9  20
    //                             / \
    //                            15  7

    const root = new Node(3);
    const node9 = new Node(9);
    const node20 = new Node(20);
    const node15 = new Node(15);
    const node7 = new Node(7);

    root.left = node9;
    root.right = node20;
    node20.left = node15;
    node20.right = node7;

    expect(maxDepth(root)).toBe(3);
  });

  test('Should handle a tree with a single root node', () => {
    const root = new Node(1);
    expect(maxDepth(root)).toBe(1);
  });

  test('Should calculate the maximum depth of a binary tree with only left children', () => {
    // Create the binary tree:    1
    //                           /
    //                          2
    //                         /
    //                        3
    //                       /
    //                      4

    const root = new Node(1);
    const node2 = new Node(2);
    const node3 = new Node(3);
    const node4 = new Node(4);

    root.left = node2;
    node2.left = node3;
    node3.left = node4;

    expect(maxDepth(root)).toBe(4);
  });
});

```

Тестовите случаи гарантират, че функцията `maxDepth` правилно изчислява максималната дълбочина на различни двоични дървета, включително крайни случаи на празни дървета и дървета само с един коренов възел.
