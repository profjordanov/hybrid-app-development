# Предизвикателство: Най-дълга последователна поредица

## Инструкции

Напишете функция, наречена `longestConsecutiveSequence`, която приема масив от цели числа като вход и връща дължината на най-дългата последователна поредица от цели числа в масива.

Последователна поредица е поредица от последователни цели числа, което означава, че всяко цяло число в поредицата е точно с едно по-голямо от предходното.

### Сигнатура на функцията

```js
/**
 * Returns the length of the longest consecutive sequence in the array.
 * @param {number[]} nums - An array of integers.
 * @returns {number} - The length of the longest consecutive sequence.
 */
function longestConsecutiveSequence(nums: number[]): number
```

### Примери

```js
longestConsecutiveSequence([100, 4, 200, 1, 3, 2]); // Output: 4 (The longest consecutive sequence is [1, 2, 3, 4])
longestConsecutiveSequence([0, 3, 7, 2, 5, 8, 4, 6, 9, 1]); // Output: 10 (The longest consecutive sequence is [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
```

### Ограничения

- Входният масив ще съдържа само цели числа
- Входният масив може да съдържа дублирани цели числа

### Подсказки

- Можете да използвате Set за ефективно намиране на последователни поредици в масива.

## Решения

<details>
  <summary>Натиснете за решение</summary>

```js
function longestConsecutiveSequence(nums) {
  const numSet = new Set(nums);
  let longestSequence = 0;

  for (const num of numSet) {
    if (!numSet.has(num - 1)) {
      let currentNum = num;
      let currentSequence = 1;

      while (numSet.has(currentNum + 1)) {
        currentNum++;
        currentSequence++;
      }

      longestSequence = Math.max(longestSequence, currentSequence);
    }
  }

  return longestSequence;
}
```

### Обяснение

- Създайте Set, наречен `numSet`, от входния масив `nums`. Set-ът ще ни позволи ефективно да проверяваме дали дадено цяло число съществува в масива за константно време.
- Инициализирайте променлива `longestSequence` на 0, която ще съхранява дължината на най-дългата последователна поредица, намерена досега.
- Итерирайте през всяко цяло число `num` в `numSet`, използвайки цикъл `for...of`. За всяко цяло число проверете дали предходното му цяло число `num - 1` съществува в `numSet`. Ако `num - 1` не присъства, това означава, че `num` е началният елемент на последователна поредица.
- Инициализирайте две променливи `currentNum` и `currentSequence`. `currentNum` е зададено на текущото цяло число `num`, а `currentSequence` е зададено на 1, тъй като сме намерили първия елемент от последователна поредица.
- Използвайте цикъл `while`, за да итерирате, докато следващото цяло число `currentNum + 1` съществува в `numSet`. За всяка итерация увеличете `currentNum` и `currentSequence`, за да удължите последователната поредица.
- След като цикълът `while` приключи, обновете `longestSequence` до максималната стойност между текущия `longestSequence` и `currentSequence`. По този начин следим най-дългата последователна поредица, намерена досега.
- След като цикълът приключи, върнете `longestSequence` като краен резултат, който представлява дължината на най-дългата последователна поредица във входния масив.

</details>

### Тестови случаи

```js
test('Longest Consecutive Sequence', () => {
  expect(longestConsecutiveSequence([100, 4, 200, 1, 3, 2])).toBe(4);
  expect(longestConsecutiveSequence([0, 3, 7, 2, 5, 8, 4, 6, 9, 1])).toBe(10);
});
```

**Забележка**: Трябва да дефинирате функцията `longestConsecutiveSequence`, както е показано в примера. Тестовите случаи проверяват дали функцията правилно връща дължината на най-дългата последователна поредица във входния масив.
