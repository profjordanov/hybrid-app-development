# Предизвикателство: Групиране на анаграми

Анаграмите са думи или фрази, образувани чрез пренареждане на буквите на друга дума или фраза. Например `cinema` е анаграма на `iceman`.

## Инструкции

Напишете функция, наречена `anagramGrouping`, която приема масив от низове като вход и връща масив от масиви, където всеки подмасив съдържа думи, които са анаграми една на друга.

### Сигнатура на функцията

```js
/**
 * Returns an array of arrays, where each sub-array contains words that are anagrams of each other.
 * @param {string[]} words - The input array of strings containing words.
 * @returns {string[][]} - The array of arrays with anagram groups.
 */
function anagramGrouping(words: string[]): string[][];
```

### Примери

```js
anagramGrouping(['cat', 'act', 'dog', 'god', 'tac']);
// Output: [['cat', 'act', 'tac'], ['dog', 'god']]

anagramGrouping(['listen', 'silent', 'enlist', 'hello', 'world']);
// Output: [['listen', 'silent', 'enlist'], ['hello'], ['world']]
```

### Ограничения

- Входният масив `words` ще съдържа само малки латински букви.

### Подсказки

- Можете да използвате map за съхраняване на групите анаграми, където ключът е сортираните символи на всяка дума, а стойността е масив от думи, които имат същите сортирани символи
- Можете да сортирате низ, като го разделите на масив от символи, извикате `.sort()` и след това го обедините обратно в низ с `join()`
- Можете да използвате `Array.from()`, за да преобразувате map в масив

## Решения

<details>
  <summary>Натиснете за решение</summary>

```js
function anagramGrouping(words) {
  const anagramGroups = new Map();

  for (const word of words) {
    const sortedChars = word.split('').sort().join('');
    if (anagramGroups.has(sortedChars)) {
      anagramGroups.get(sortedChars).push(word);
    } else {
      anagramGroups.set(sortedChars, [word]);
    }
  }

  return Array.from(anagramGroups.values());
}
```

### Обяснение

- Създайте нов map `anagramGroups` за съхраняване на групите анаграми.
- Итерирайте през всяка дума във входния масив `words`. За всяка дума разделете символите ѝ в масив, сортирайте масива във възходящ ред и след това обединете сортираните символи обратно в низ. Този сортиран низ става ключ за нашия map `anagramGroups`.
- Проверете дали ключът вече съществува в map-а. Ако съществува, извлечете съответния масив и добавете думата към него.
- Ако ключът не съществува в map-а, създайте нов масив с думата като първи елемент и го добавете към map-а с този ключ.
- След обработка на всички думи, извлечете масивите с групи анаграми от map-а `anagramGroups` чрез `Array.from(anagramGroups.values())` и ги върнете като краен резултат.

</details>

### Тестови случаи

```js
test('Grouping anagrams', () => {
  const result1 = anagramGrouping(['cat', 'act', 'dog', 'god', 'tac']);
  const result2 = anagramGrouping([
    'listen',
    'silent',
    'enlist',
    'hello',
    'world',
  ]);

  expect(result1).toEqual([
    ['cat', 'act', 'tac'],
    ['dog', 'god'],
  ]);
  expect(result2).toEqual([
    ['listen', 'silent', 'enlist'],
    ['hello'],
    ['world'],
  ]);
});
```
