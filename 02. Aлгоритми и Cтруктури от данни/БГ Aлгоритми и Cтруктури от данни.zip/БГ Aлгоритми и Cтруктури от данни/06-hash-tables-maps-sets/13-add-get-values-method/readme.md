# Предизвикателство: Метод getValues за HashTable

## Инструкции

Разширете съществуващия клас `HashTable` с нов метод, наречен `getValues()`. Този метод трябва да връща масив, съдържащ всички стойности, съхранени в хеш таблицата, независимо от ключовете.

Добавете метода `getValues()` във файла `HashTable.js`.

### Примери

```javascript
const myHashTable = new HashTable();

myHashTable.set('name', 'Alice');
myHashTable.set('age', 30);
myHashTable.set('city', 'New York');

console.log(myHashTable.getValues()); // Expected output: ['Alice', 30, 'New York']
```

### Подсказки

- Трябва да итерирате през всички кофи (buckets) в масива за съхранение и всички двойки ключ-стойност във всяка кофа.
- Създайте масив за съхраняване на стойностите, итерирайте през всяка кофа и след това итерирайте през всяка двойка ключ-стойност. Добавете всяка стойност към масива.
- След итериране през всички двойки ключ-стойност, върнете масива със стойности.

### Решения

<details>
  <summary>Натиснете за решение</summary>

```js
 getValues() {
    const values = [];

    for (let i = 0; i < this.storage.length; i++) {
      if (this.storage[i]) {
        for (const [key, value] of this.storage[i]) {
          values.push(value);
        }
      }
    }

    return values;
  }
```

</details>

### Тестови случаи

```js
const HashTable = require('./HashTable');

describe('HashTable', () => {
  let hashTable;

  beforeEach(() => {
    hashTable = new HashTable();
  });

  test('Get values from hash table', () => {
    hashTable.set('name', 'Alice');
    hashTable.set('age', 30);
    hashTable.set('city', 'New York');

    const values = hashTable.getValues();
    expect(values).toEqual(expect.arrayContaining(['Alice', 30, 'New York']));
    expect(values).toHaveLength(3);
  });

  test('Get values from an empty hash table', () => {
    const values = hashTable.getValues();
    expect(values).toEqual([]);
  });
});
```
