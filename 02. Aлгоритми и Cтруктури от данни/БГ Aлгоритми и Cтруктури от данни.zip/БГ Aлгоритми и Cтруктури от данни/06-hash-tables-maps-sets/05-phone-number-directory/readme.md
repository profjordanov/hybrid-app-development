# Предизвикателство: Телефонен указател

## Инструкции

Вие изграждате приложение за телефонен указател. Имплементирайте функция, наречена `phoneNumberDirectory`, която приема масив от телефонни номера като вход и връща Map с имена като ключове и съответните телефонни номера като стойности.

### Сигнатура на функцията

```js
/**
 * Builds a phone number directory from an array of phone numbers.
 *
 * @param {string[]} phoneNumbers - An array of phone numbers in the format "Name:PhoneNumber".
 * @returns {Map<string, string>} - A Map with names as keys and corresponding phone numbers as values.
 */
function phoneNumberDirectory(phoneNumbers: string[]): Map<string, string>
```

### Примери

```js
const phoneNumbers = [
  'John:123-456-7890',
  'Jane:987-654-3210',
  'Joe:555-555-5555',
];

console.log(phoneNumberDirectory(phoneNumbers));
// Output: Map { 'John' => '123-456-7890', 'Jane' => '987-654-3210', 'Joe' => '555-555-5555' }
```

### Ограничения

- Елементите на входния масив трябва да бъдат форматирани като `ИМЕ:ТЕЛЕФОНЕН_НОМЕР`

### Подсказки

- Преминете през входния масив и използвайте метода `split()`, за да разделите името и телефонния номер във всеки елемент от масива `phoneNumbers`, преди да ги добавите в map-а

## Решения

<details>
  <summary>Натиснете за решение</summary>

```js
function phoneNumberDirectory(phoneNumbers) {
  const directory = new Map();

  for (const entry of phoneNumbers) {
    const [name, phoneNumber] = entry.split(':');
    directory.set(name, phoneNumber);
  }

  return directory;
}
```

### Обяснение

- Създайте нов Map, наречен `directory`
- Итерирайте през масива `phoneNumbers`, използвайки цикъл `for...of`
- Използвайте метода `split()`, за да разделите името и телефонния номер от всеки запис, като използвате двоеточието `:` като разделител
- Задайте всяко име като ключ и съответния му телефонен номер като стойност в Map-а
- Върнете `directory`, който вече съдържа телефонния указател

</details>

### Тестови случаи

```js
test('Building a phone number directory from an array of phone numbers', () => {
  const phoneNumbers = [
    'John:123-456-7890',
    'Jane:987-654-3210',
    'Joe:555-555-5555',
  ];

  const result = phoneNumberDirectory(phoneNumbers);

  expect(result.get('John')).toBe('123-456-7890');
  expect(result.get('Jane')).toBe('987-654-3210');
  expect(result.get('Joe')).toBe('555-555-5555');
});
```
