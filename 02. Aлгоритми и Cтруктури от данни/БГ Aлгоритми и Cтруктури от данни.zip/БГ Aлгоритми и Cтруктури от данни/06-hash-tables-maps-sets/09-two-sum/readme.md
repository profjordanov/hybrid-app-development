# Предизвикателство: Сума от две числа (Two Sum)

## Инструкции

Напишете функция, наречена `twoSum`, която приема масив от цели числа и целево цяло число като вход и връща масив от индексите на двете числа, чиято сума е равна на целевата стойност.

### Сигнатура на функцията

```javascript
/**
 * Returns an array of indices of two numbers that add up to the target.
 * @param {number[]} nums - The input array of integers.
 * @param {number} target - The target sum.
 * @returns {number[]} - An array of indices of the two numbers.
 */
function twoSum(nums: number[], target: number): number[]
```

### Примери

```javascript
console.log(twoSum([2, 7, 11, 15], 9));
// Output: [0, 1] (2 + 7 = 9)

console.log(twoSum([3, 2, 4], 6));
// Output: [1, 2] (2 + 4 = 6)

console.log(twoSum([3, 3], 6));
// Output: [0, 1] (3 + 3 = 6)
```

### Ограничения

- Всяко входно цяло число е уникално.

### Подсказки

- Можете да използвате Set, за да следите числата, които сте видели досега, докато итерирате през масива.

### Решение

<details>
  <summary>Натиснете за решение</summary>

```javascript
function twoSum(nums, target) {
  const numSet = new Set();

  for (let i = 0; i < nums.length; i++) {
    const complement = target - nums[i];
    if (numSet.has(complement)) {
      return [nums.indexOf(complement), i];
    }
    numSet.add(nums[i]);
  }

  return [];
}
```

### Обяснение

- Създайте `Set`, наречен `numSet`, за съхраняване на числата, които са били видени при итериране през масива.
- Итерирайте през входния масив `nums`. За всяко число изчислете неговото допълнение (числото, необходимо за достигане на целевата стойност) като `target - nums[i]`.
- Ако допълнението вече е в `numSet`, върнете масив, съдържащ индексите на допълнението и текущото число.
- Ако допълнението не е в `numSet`, добавете текущото число към set-а.
- Ако не е намерено решение, върнете празен масив.

</details>

### Тестови случаи

```javascript
const twoSum = require('./twoSum');

describe('Two Sum', () => {
  test('Test 1', () => {
    const nums = [2, 7, 11, 15];
    const target = 9;
    const result = twoSum(nums, target);
    expect(result).toEqual(expect.arrayContaining([0, 1]));
  });

  test('Test 2', () => {
    const nums = [3, 2, 4];
    const target = 6;
    const result = twoSum(nums, target);
    expect(result).toEqual(expect.arrayContaining([1, 2]));
  });

  test('Test 3', () => {
    const nums = [3, 3];
    const target = 6;
    const result = twoSum(nums, target);
    expect(result).toEqual(expect.arrayContaining([0, 1]));
  });
});
```
