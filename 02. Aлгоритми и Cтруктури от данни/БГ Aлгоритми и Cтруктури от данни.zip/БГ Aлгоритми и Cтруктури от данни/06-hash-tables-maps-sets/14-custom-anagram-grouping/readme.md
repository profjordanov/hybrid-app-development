# Предизвикателство: Групиране на анаграми

## Инструкции

Създайте функция, наречена `anagramGrouping`, която използва класа `HashTable`, който създадохме. Функцията трябва да приема масив от думи като вход и да връща масив от масиви, където всеки вътрешен масив представлява група от анаграми.

### Сигнатура на функцията

```js
/**
 * Groups anagrams from the input array of words using a HashTable.
 * @param {string[]} words - An array of words.
 * @returns {string[][]} - An array of arrays, each representing a group of anagrams.
 */
function anagramGrouping(words: string[]): string[][];
```

### Примери

```js
anagramGrouping(['listen', 'silent', 'hello', 'world', 'act', 'cat']);
// Output: [['listen', 'silent'], ['act', 'cat'], ['hello'], ['world']]
```

### Подсказки

- Можете да използвате предоставения клас `HashTable` за имплементиране на ефективно групиране на анаграми.
- Преобразувайте всяка дума в сортиран низ от символи, за да идентифицирате анаграмите.
- За всеки сортиран низ съхранете анаграмите в HashTable с него като ключ.

## Решение

<details>
  <summary>Натиснете за решение</summary>

```js
const HashTable = require('./HashTable');

function anagramGrouping(words) {
  const anagramGroups = new HashTable();

  for (const word of words) {
    const sortedChars = word.split('').sort().join('');
    if (anagramGroups.get(sortedChars)) {
      anagramGroups.get(sortedChars).push(word);
    } else {
      anagramGroups.set(sortedChars, [word]);
    }
  }

  return anagramGroups.getValues();
}

module.exports = anagramGrouping;
```

### Обяснение

Това е много подобно на групирането на анаграми, където използвахме maps.

- Заменете `Map` с `HashTable` за ефективно групиране на анаграми.
- Итерирайте през всяка дума във входния масив и създайте сортирана версия на символите на думата.
- Този сортиран низ се използва като ключ в `HashTable`. Ако ключът вече съществува в `HashTable`, добавяме текущата дума към списъка с анаграми. Ако ключът не съществува, създаваме нов запис в `HashTable` с ключа и масив, съдържащ текущата дума.
- След итериране през всички думи, използвайте метода `getValues` на `HashTable`, за да получите масив от масиви, където всеки вътрешен масив представлява група от анаграми.
- Върнете масива с групи анаграми.

</details>

### Тестови случаи

```js
test('Grouping anagrams from an array of words', () => {
  const result1 = anagramGrouping([
    'listen',
    'silent',
    'hello',
    'world',
    'act',
    'cat',
  ]);
  expect(result1).toEqual(
    expect.arrayContaining([
      expect.arrayContaining(['listen', 'silent']),
      expect.arrayContaining(['act', 'cat']),
      expect.arrayContaining(['hello']),
      expect.arrayContaining(['world']),
    ])
  );
});
```
