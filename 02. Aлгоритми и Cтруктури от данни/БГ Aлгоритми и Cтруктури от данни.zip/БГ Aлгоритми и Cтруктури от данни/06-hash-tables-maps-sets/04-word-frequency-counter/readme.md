# Предизвикателство: Брояч на честота на думи

## Инструкции

Напишете функция, наречена `wordFrequencyCounter`, която приема низ като вход и връща map, представящ честотата на всяка дума в низа. Направихме подобно предизвикателство преди, което броеше появите на символ. Тази функция трябва да брои появите на всяка дума, игнорирайки главни/малки букви и изключвайки пунктуацията.

### Сигнатура на функцията

```js
/**
 * Returns a map that represents the frequency of each word in the input string.
 * @param {string} str - The input string containing words.
 * @returns {Map<string, number>} - The map with word frequency.
 */
function wordFrequencyCounter(str) {
  // Your code here
}
```

### Примери

```js
wordFrequencyCounter('The quick brown fox jumps over the lazy dog.');
// Output: Map { 'the' => 2, 'quick' => 1, 'brown' => 1, 'fox' => 1, 'jumps' => 1, 'over' => 1, 'lazy' => 1, 'dog' => 1 }

wordFrequencyCounter(
  'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
);
// Output: Map { 'lorem' => 1, 'ipsum' => 1, 'dolor' => 1, 'sit' => 1, 'amet' => 1, 'consectetur' => 1, 'adipiscing' => 1, 'elit' => 1 }
```

### Ограничения

- Входният низ ще съдържа само букви, интервали и пунктуационни знаци.

### Подсказки

- Можете да използвате метода `toLowerCase()`, за да преобразувате входния низ в малки букви, така че да игнорирате главни/малки букви при броенето на честотата на думите.
- Регулярните изрази могат да бъдат полезни за разделяне на низа на думи и премахване на пунктуационните знаци.
- Можете да използвате map за съхраняване на честотите на думите, където думата е ключът, а броят е стойността. Преминете през всяка дума, обновете броя в map-а и върнете крайния map.

### Обяснение

- Създайте променлива `words`, за да съхраните версията с малки букви на входния низ, разделена на масив от думи. Регулярният израз `/W+/` съвпада с един или повече несловесни символа, което включва интервали и пунктуационни знаци. Това ще раздели низа на масив от думи, игнорирайки интервалите и пунктуационните знаци.

- Създайте празен `Map`, наречен `wordFrequency`, за съхраняване на честотите на думите.

- Итерирайте през всяка дума в масива. Ако думата е празен низ (което може да бъде причинено от множество интервали или пунктуационни знаци), пропуснете я чрез `continue`. В противен случай проверяваме дали думата вече е в map-а.
- Ако е, увеличаваме честотата ѝ с 1. Ако не е в map-а, я добавяме в map-а с честота 1.
- Върнете map-а `wordFrequency`, който съдържа честотата на всяка дума във входния низ.

</details>

### Тестови случаи

```js
test('Counting word frequencies in a string', () => {
  const result1 = wordFrequencyCounter(
    'The quick brown fox jumps over the lazy dog.'
  );
  const result2 = wordFrequencyCounter(
    'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
  );

  expect(result1.get('the')).toBe(2);
  expect(result1.get('quick')).toBe(1);
  expect(result1.get('brown')).toBe(1);
  expect(result1.get('fox')).toBe(1);
  expect(result1.get('jumps')).toBe(1);
  expect(result1.get('over')).toBe(1);
  expect(result1.get('lazy')).toBe(1);
  expect(result1.get('dog')).toBe(1);

  expect(result2.get('lorem')).toBe(1);
  expect(result2.get('ipsum')).toBe(1);
  expect(result2.get('dolor')).toBe(1);
  expect(result2.get('sit')).toBe(1);
  expect(result2.get('amet')).toBe(1);
  expect(result2.get('consectetur')).toBe(1);
  expect(result2.get('adipiscing')).toBe(1);
  expect(result2.get('elit')).toBe(1);
});
```
