# Предизвикателство: Симетрична разлика

## Инструкции

Ще започнем с доста просто предизвикателство. Напишете функция, наречена `symmetricDifference`, която приема два масива и връща масив, съдържащ симетричната разлика на двата масива. Симетричната разлика на два масива е нов масив, съдържащ само елементите, които присъстват в един от масивите, но не и в двата, без дубликати.

### Сигнатура на функцията

```js
/**
 * Returns an array containing the symmetric difference of two arrays.
 * @param {number[]} arr1 - The first array of integers.
 * @param {number[]} arr2 - The second array of integers.
 * @returns {number[]} - The array containing the symmetric difference of the two arrays.
 */
function symmetricDifference(arr1: number[], arr2: number[]): number[]
```

### Примери

```js
symmetricDifference([1, 2, 3], [3, 4, 5]);
// Output: [1, 2, 4, 5]

symmetricDifference([1, 2, 2, 3, 4], [2, 3, 3, 4, 5]);
// Output: [1, 5]

symmetricDifference([1, 2, 3, 4, 5], [5, 4, 3, 2, 1]);
// Output: []

symmetricDifference([1, 2, 3], [4, 5, 6]);
// Output: [1, 2, 3, 4, 5, 6]
```

### Подсказки

- Можете да използвате два Set-а, за да следите елементите и в двата масива, и след това да намерите елементите, които присъстват само в един от set-овете.
- Бъдете внимателни с дублираните елементи и ги обработете правилно.

## Решения

<details>
  <summary>Натиснете за решение</summary>

```js
function symmetricDifference(arr1, arr2) {
  const set1 = new Set(arr1);
  const set2 = new Set(arr2);
  const result = [];

  for (const num of arr1) {
    if (!set2.has(num)) {
      result.push(num);
    }
  }

  for (const num of arr2) {
    if (!set1.has(num)) {
      result.push(num);
    }
  }

  return result;
}
```

### Обяснение

- За да намерим симетричната разлика, създаваме два `Set` обекта, `set1` и `set2`, от `arr1` и `arr2` съответно. Структурата от данни `Set` ни позволява ефективно да проверяваме за наличието на елемент.
- Инициализираме празен масив, наречен `result`, за да съхраним симетричната разлика.
- Итерираме през всеки елемент в `arr1`, използвайки цикъл `for...of`. За всеки елемент в `arr1` използваме метода `has()` на `set2`, за да проверим дали елементът съществува в `set2`. Ако елементът не е намерен в `set2`, това означава, че присъства в `arr1`, но не и в `arr2`, и го добавяме в масива `result`.
- По подобен начин итерираме през всеки елемент в `arr2`, използвайки друг цикъл `for...of`. За всеки елемент в `arr2` използваме метода `has()` на `set1`, за да проверим дали елементът съществува в `set1`. Ако елементът не е намерен в `set1`, това означава, че присъства в `arr2`, но не и в `arr1`, и го добавяме в масива `result`.
- Връщаме масива `result`, който съдържа елементите, присъстващи само в един от входните масиви, без дубликати.

</details>

### Тестови случаи

```js
test('Symmetric Difference of Two Arrays', () => {
  expect(symmetricDifference([1, 2, 3], [3, 4, 5])).toEqual([1, 2, 4, 5]);
  expect(symmetricDifference([1, 2, 2, 3, 4], [2, 3, 3, 4, 5])).toEqual([1, 5]);
  expect(symmetricDifference([1, 2, 3, 4, 5], [5, 4, 3, 2, 1])).toEqual([]);
  expect(symmetricDifference([1, 2, 3], [4, 5, 6])).toEqual([1, 2, 3, 4, 5, 6]);
});
```
