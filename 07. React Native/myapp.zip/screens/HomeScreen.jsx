import React, { useState } from 'react';
import { StyleSheet, Text, View, Button } from 'react-native';
import Form from '../components/Form';
import CardList from '../components/CardList';
import { useAuth } from '../context/AuthContext';

export default function HomeScreen() {
  const { isLoggedIn, userData, logout, setIsLoggedIn } = useAuth();

  const [profiles, setProfiles] = useState([]);

  const addNewProfile = (profileData) => {
    setProfiles((profiles) => [profileData, ...profiles])
  }

  const removeProfile = (id) =>{
    setProfiles((profiles) => profiles.filter((rec) => id !== rec.id));
  }

  return (
    <View style={styles.container}>
      <Text>My APP = {isLoggedIn && userData}</Text>
      <Form onSubmit={addNewProfile} />
      <CardList 
      profiles={profiles}
      removeProfile={removeProfile}
      />
      <View>
        <Text>-------</Text>
        <Text>Logout</Text>
        <Button title="Logout" onPress={logout} />
        <Button title="setIsLoggedIn" onPress={setIsLoggedIn} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});