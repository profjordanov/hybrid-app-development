import React, { useState } from 'react';
import { useAuth } from "../context/AuthContext";
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';

export default function LoginScreen({ navigation }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const { login } = useAuth();

  const handleLogin = () => {
    if (username && password) {
      login(username + ":" + password);
      navigation.navigate('Home');
    } else {
      alert('Please enter username and password');
    }
  };

  const handleFirebase = () => {
    navigation.navigate('Fire');
  };

  const handleCamera = () => {
    navigation.navigate('Camera');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Login</Text>
      <TextInput
        style={styles.input}
        placeholder="Username"
        value={username}
        onChangeText={(text) => setUsername(text)}
      />
      <TextInput
        style={styles.input}
        placeholder="Password"
        value={password}
        onChangeText={(text) => setPassword(text)}
        secureTextEntry
      />
      <Button title="Login" onPress={handleLogin} />

      <View>
        <Text>-------</Text>
        <Text>Firebase</Text>
        <Button title="Firebase" onPress={handleFirebase} />
        <Text>-------</Text>
        <Text>Camera</Text>
        <Button title="Camera" onPress={handleCamera} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 16,
  },
  title: {
    fontSize: 24,
    textAlign: 'center',
    marginBottom: 20,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 8,
  },
});