import React, { useState } from 'react';
import {
    TextInput,
    Button,
    SafeAreaView
} from 'react-native';
import axios from 'axios';

const Form = ({onSubmit}) => {
    const [userName, setUserName] = useState("");

    const handleSubmit = async (username) => {
        try{
            const resp = await axios.get(`https://api.github.com/users/${username}`);
            onSubmit(resp.data);
            setUserName("");
        }
        catch (ex){
            alert(ex);
        }
    };

    return(
        <SafeAreaView>
            <TextInput
            type="text"
            value={userName}
            onChangeText={
                (username) => setUserName(username)}
            ref={input => {
                this.textInput = input;
            }}
             />
            <Button title="Add" 
            onPress={() => handleSubmit(userName)}
            />
        </SafeAreaView>
    );
};
export default Form;
