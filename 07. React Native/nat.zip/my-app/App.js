import React, {useState} from "react";
import CardList from './components/CardList';
import Form from './components/Form'; 
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';

export default function App() {
  const [profiles, setProfiles] = useState([]);

  const addNewProfile = (profileData) => {
    setProfiles((profiles) => [profileData, ...profiles])
  }

  const removeProfile = (id) =>{
    setProfiles((profiles) => profiles.filter((rec) => id !== rec.id));
  }

  return (
    <View style={styles.container}>
      <Text>My APP!</Text>
      <Form onSubmit={addNewProfile} />
      <CardList 
      profiles={profiles}
      removeProfile={removeProfile}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
