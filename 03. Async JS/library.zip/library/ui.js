const kinveyBaseUrl = "https://baas.kinvey.com/";
const kinveyAppKey = "kid_B1tAcBVpa";
const kinveyAppSecret = "8fd81440a7db4a2f80692e1ff325aa6b";

// Function to show a specific view
export function showView(viewName) {
    const sections = document.querySelectorAll('main > section');
    sections.forEach(section => section.style.display = 'none');
    document.getElementById(viewName).style.display = 'block';
}

// Function to initialize event listeners
export function setupEventListeners() {
    document.getElementById('linkHome').addEventListener('click', () => showHomeView());
    document.getElementById('linkListBooks').addEventListener('click', listBooks);
    document.getElementById('linkCreateBook').addEventListener('click', () => showCreateBookView());

    document.getElementById('buttonCreateBook').addEventListener('click', createBook);
    document.getElementById('buttonEditBook').addEventListener('click', editBook);

    document.querySelectorAll('#infoBox, #errorBox').forEach(box => {
        box.addEventListener('click', () => box.style.display = 'none');
    });
}

// Functions for showing specific views
function showHomeView() {
    showView('viewHome');
}

function showCreateBookView() {
    document.getElementById('formCreateBook').reset();
    showView('viewCreateBook');
}

export function showInfo(message) {
    const infoBox = document.getElementById('infoBox');
    infoBox.textContent = message;
    infoBox.style.display = 'block';
    setTimeout(() => infoBox.style.display = 'none', 3000);
}

export function showError(errorMsg) {
    const errorBox = document.getElementById('errorBox');
    errorBox.textContent = "Error: " + errorMsg;
    errorBox.style.display = 'block';
}

function listBooks() {
    document.getElementById('books').innerHTML = '';
    showView('viewBooks');

    fetch(kinveyBaseUrl + "appdata/" + kinveyAppKey + "/books", {
            method: "GET",
            headers: getKinveyUserAuthHeaders()
        })
        .then(response => response.json())
        .then(loadBooksSuccess)
        .catch(handleAjaxError);

    function loadBooksSuccess(books) {
        showInfo('Books loaded.');
        if (books.length === 0) {
            document.getElementById('books').textContent = 'No books in the library.';
        } else {
            let booksTable = document.createElement('table');
            booksTable.classList.add('table', 'table-striped');

            let thead = document.createElement('tr');
            thead.innerHTML = '<th>Title</th><th>Author</th><th>Description</th><th>Actions</th>';
            booksTable.appendChild(thead);

            books.forEach(book => {
                appendBookRow(book, booksTable);
            });

            document.getElementById('books').appendChild(booksTable);
        }
    }

    function appendBookRow(book, booksTable) {
        let links = [];

        let deleteLink = document.createElement('a');
        deleteLink.href = "#";
        deleteLink.textContent = '[Delete]';
        deleteLink.addEventListener('click', function () {
            deleteBook(book._id);
        });

        let editLink = document.createElement('a');
        editLink.href = "#";
        editLink.textContent = '[Edit]';
        editLink.addEventListener('click', function () {
            loadBookForEdit(book);
        });

        links = [deleteLink, ' ', editLink];

        let tr = document.createElement('tr');
        tr.innerHTML = `<td>${book.title}</td><td>${book.author}</td><td>${book.description}</td>`;
        let td = document.createElement('td');
        links.forEach(link => {
            if (typeof link === 'string') {
                td.appendChild(document.createTextNode(link));
            } else {
                td.appendChild(link);
            }
        });
        tr.appendChild(td);
        booksTable.appendChild(tr);
    }
}

export function handleAjaxError(response) {
    let errorMsg = 'An error occurred while processing your request.';

    if (response.json && typeof response.json === 'function') {
        return response.json().then(json => {
            if (json && json.error) {
                errorMsg = json.error;
            }
            throw new Error(errorMsg);
        });
    } else {
        throw new Error(errorMsg);
    }
}

// Function to create a new book
export function createBook() {
    let bookData = {
        title: document.querySelector('#formCreateBook input[name=title]').value,
        author: document.querySelector('#formCreateBook input[name=author]').value,
        description: document.querySelector('#formCreateBook textarea[name=descr]').value
    };

    fetch(kinveyBaseUrl + "appdata/" + kinveyAppKey + "/books", {
            method: "POST",
            headers: {
                ...getKinveyUserAuthHeaders(),
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(bookData)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(createBookSuccess)
        .catch(handleAjaxError);

    function createBookSuccess(response) {
        listBooks();
        showInfo('Book created.');
    }
}

// Function to edit a book
export function editBook(bookId, bookData) {
    // AJAX call to edit a book
    return fetch(kinveyBaseUrl + "appdata/" + kinveyAppKey + "/books/" + bookId, {
            method: "PUT",
            headers: getKinveyUserAuthHeaders(),
            body: JSON.stringify(bookData)
        })
        .then(response => response.json());
}

function deleteBook(bookId) {
    // Confirmation prompt
    if (!window.confirm('Are you sure you want to delete this book?')) {
        return; // If the user clicks 'Cancel', exit the function
    }

    fetch(kinveyBaseUrl + "appdata/" + kinveyAppKey + "/books/" + bookId, {
            method: "DELETE",
            headers: getKinveyUserAuthHeaders()
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(deleteBookSuccess)
        .catch(handleAjaxError);

    function deleteBookSuccess(response) {
        listBooks();
        showInfo('Book deleted.');
    }
}


// Function to get user authentication headers
export function getKinveyUserAuthHeaders() {
    // Implementation to get user auth headers
    return {
        "Authorization": "Kinvey " + "e0585d1c-abeb-40d2-9757-fc05ee640c5a.cHE+f5D3Ex+bWvh/3ch3G9OxJEhI/cmCG+zcdpADsxU="
    };
}