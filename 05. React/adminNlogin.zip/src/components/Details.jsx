import React from 'react';
import { useLocation } from 'react-router-dom';

const Details = () => {
  const location = useLocation();
  const { student } = location.state || {};
  const current = sessionStorage.getItem('token');

  if (!student) {
    return <div className="alert alert-warning">No student details available. Current {current}</div>;
  }

  return (
    <div className="container mt-4">
      <h2 className="mb-4">{student.fullName}</h2>
      <div className="card">
        <div className="card-body">
          <h5 className="card-title"></h5>
          <p className="card-text"><strong>Faculty Number:</strong> {student.facultyNumber}</p>
          <p className="card-text"><strong>Username:</strong> {student.userName}</p>
          {student.base64EncodePicture && (
            <img 
              src={`data:image/jpeg;base64,${student.base64EncodePicture}`} 
              alt="Student" 
              className="img-fluid mt-3"
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default Details;