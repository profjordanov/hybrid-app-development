import { useState } from "react";
import { useAuth } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

function Login() {
  const [userNameOrEmail, setuserNameOrEmail] = useState("");
  const [password, setPassword] = useState("");
  const { login } = useAuth();
  const navigate = useNavigate();

  const loginHadler = async (event) => {
    event.preventDefault();

    if (userNameOrEmail && password) {
      const loginRequest = userNameOrEmail + ":" + password;
      try {
        login(loginRequest);
        navigate("/");
      } catch (error) {
        handleError(error);
      }
    }
  };

  const handleError = (error) => {
    console.error(error);
  };

  return (
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-md-6">
          <div className="card">
            <div className="card-body">
              <h1 className="card-title">Login</h1>
              <form onSubmit={loginHadler}>
                <div className="form-group">
                  <label htmlFor="userNameOrEmail">Username or Email</label>
                  <input
                    type="text"
                    id="userNameOrEmail"
                    className="form-control"
                    value={userNameOrEmail}
                    onChange={(e) => setuserNameOrEmail(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="password">Password</label>
                  <input
                    type="password"
                    id="password"
                    className="form-control"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>
                <button type="submit" className="btn btn-primary mt-3">
                  Login
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Login;