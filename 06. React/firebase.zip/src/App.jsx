import React, { useState } from 'react';
import FetchData from './FetchData';
import AddDataForm from './AddDataForm';

const App = () => {
    const [data, setData] = useState([]);

    return (
        <div>
            <h1>Firestore with React</h1>
            <FetchData data={data} setData={setData} />
            <br/>
            <AddDataForm data={data} setData={setData} />
        </div>
    );
};

export default App;