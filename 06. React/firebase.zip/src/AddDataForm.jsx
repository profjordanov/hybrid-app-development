import React, { useState } from 'react';
import { db } from './firebase';
import { collection, addDoc } from 'firebase/firestore';

const AddDataForm = ({ data, setData }) => {
    const [title, setTitle] = useState('');
    const [author, setAuthor] = useState('');

    const handleTitleChange = (e) => {
        setTitle(e.target.value);
    };

    const handleAuthorChange = (e) => {
        setAuthor(e.target.value);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const formData = { title, author };
            const docRef = await addDoc(collection(db, 'books'), formData);
            setTitle('');
            setAuthor('');
            setData([...data, { id: docRef.id, ...formData }]);
            alert('Document added successfully!');
        } catch (error) {
            console.error('Error adding document: ', error);
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <div>
                <label htmlFor="title">Title:</label>
                <input
                    type="text"
                    id="title"
                    name="title"
                    value={title}
                    onChange={handleTitleChange}
                    required
                />
            </div>
            <div>
                <label htmlFor="author">Author:</label>
                <input
                    type="text"
                    id="author"
                    name="author"
                    value={author}
                    onChange={handleAuthorChange}
                    required
                />
            </div>
            <br/>
            <button type="submit">Add Book</button>
        </form>
    );
};

export default AddDataForm;