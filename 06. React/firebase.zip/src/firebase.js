// src/firebase.js
import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyCN7Lr8UcvaHhwqf0VM7Vncw2PVJeq7EVc",
    authDomain: "library-2025jj.firebaseapp.com",
    databaseURL: "https://library-2025jj-default-rtdb.europe-west1.firebasedatabase.app",
    projectId: "library-2025jj",
    storageBucket: "library-2025jj.firebasestorage.app",
    messagingSenderId: "568665022380",
    appId: "1:568665022380:web:2ff03ac22686a4c0ae6409"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firestore
const db = getFirestore(app);

export { db };