import React, { useEffect } from 'react';
import { getDocs, collection } from 'firebase/firestore';
import { db } from './firebase';

const FetchData = ({ data, setData }) => {
    useEffect(() => {
        const fetchData = async () => {
            try {
                const querySnapshot = await getDocs(collection(db, 'books'));
                const books = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
                setData(books);
            } catch (error) {
                console.error('Error fetching documents: ', error);
            }
        };

        fetchData();
    }, [setData]);

    return (
        <div>
            <table>
                <thead>
                <tr>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Description</th>
                    <th>Price</th>
                    <th>In Stock</th>
                </tr>
                </thead>
                <tbody>
                {data.map((item) => (
                    <tr key={item.id}>
                        <td>{item.title}</td>
                        <td>{item.author}</td>
                        <td>{item.description}</td>
                        <td>{item.price}</td>
                        <td>{item.inStock ? 'Yes' : 'No'}</td>
                    </tr>
                ))}
                </tbody>
            </table>
        </div>
    );
};

export default FetchData;