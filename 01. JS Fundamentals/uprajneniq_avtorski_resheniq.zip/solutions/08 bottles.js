function boxesAndBottles(bottles, capacity) {
	
	let result = Math.ceil(bottles / capacity);
	
    console.log(result);
}

boxesAndBottles(20, 5);