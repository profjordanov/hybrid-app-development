function loadCommits() {
    // ensure unordered list is empty

    // get username value
    // get repo value

    // create the request url

    // execute the AJAX
}

function displayCommits(commits) {

}

function displayError(err) {

}