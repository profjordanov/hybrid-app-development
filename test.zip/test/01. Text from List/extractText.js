function extractText() {
    // TODO
}