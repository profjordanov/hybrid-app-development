function diceGameSimulation() {}

module.exports = diceGameSimulation;
