const findMissingNumber = require('./find-missing-number');

const result = findMissingNumber([10, 8, 6, 7, 5, 4, 2, 3, 1]);

console.log(result);
