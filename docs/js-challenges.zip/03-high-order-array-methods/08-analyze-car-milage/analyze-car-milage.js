function analyzeCarMileage() {}

module.exports = analyzeCarMileage;
