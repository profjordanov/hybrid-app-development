const highestScoringWord = require('./highest-scoring-word');

const result = highestScoringWord('Hello my name is xavier');

console.log(result);
