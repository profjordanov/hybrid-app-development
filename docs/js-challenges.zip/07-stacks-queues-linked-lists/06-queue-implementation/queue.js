class Queue {}

module.exports = Queue;
