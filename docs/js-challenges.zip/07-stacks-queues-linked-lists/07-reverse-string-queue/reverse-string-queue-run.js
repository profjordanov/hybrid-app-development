const reverseStringQueue = require('./reverse-string-queue');

const result = reverseStringQueue('Hello World!');

console.log(result);
