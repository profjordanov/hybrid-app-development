const longestConsecutiveSequence = require('./longest-consecutive');

const result = longestConsecutiveSequence([100, 4, 200, 1, 3, 2]);

console.log(result);
