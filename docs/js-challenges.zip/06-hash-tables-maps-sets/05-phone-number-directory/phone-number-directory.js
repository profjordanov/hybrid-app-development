function phoneNumberDirectory() {}

module.exports = phoneNumberDirectory;
