const titleCase = require('./title-case');

const result = titleCase('the quick brown fox');

console.log(result);
