const reverseString = require('./reverse-string-recursion');

const result = reverseString('hello');

console.log(result);
