const fibonacci = require('./fibonacci');

const result = fibonacci(8);

console.log(result);
