function numberRange() {}

module.exports = numberRange;
