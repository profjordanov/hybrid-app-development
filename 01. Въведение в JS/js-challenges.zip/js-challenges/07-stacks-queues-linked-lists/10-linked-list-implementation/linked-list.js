class Node {}

class LinkedList {}

module.exports = { Node, LinkedList };
