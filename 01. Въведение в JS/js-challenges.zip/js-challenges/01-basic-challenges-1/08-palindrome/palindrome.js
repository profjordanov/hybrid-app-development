function isPalindrome() {}

module.exports = isPalindrome;
