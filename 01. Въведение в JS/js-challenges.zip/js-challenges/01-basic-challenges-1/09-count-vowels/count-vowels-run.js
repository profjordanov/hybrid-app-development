const countVowels = require('./count-vowels');

const result = countVowels('Hello World!');

console.log(result);
