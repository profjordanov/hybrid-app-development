function findFirstNonRepeatingCharacter() {}

module.exports = findFirstNonRepeatingCharacter;
