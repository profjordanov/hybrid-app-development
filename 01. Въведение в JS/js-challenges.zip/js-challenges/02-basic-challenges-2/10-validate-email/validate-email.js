function validateEmail() {}

module.exports = validateEmail;
