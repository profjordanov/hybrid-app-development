function fibonacci() {}

module.exports = fibonacci;
